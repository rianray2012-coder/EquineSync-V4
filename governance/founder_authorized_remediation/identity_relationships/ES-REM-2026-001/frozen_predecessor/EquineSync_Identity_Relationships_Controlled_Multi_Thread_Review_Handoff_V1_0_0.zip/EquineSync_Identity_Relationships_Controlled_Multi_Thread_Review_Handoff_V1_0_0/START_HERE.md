# Start Here

Use this ZIP in a new Codex thread.

1. Attach the ZIP.
2. Tell Codex to read:
   `directive/CODEX_CONTROLLED_MULTI_THREAD_REVIEW_DIRECTIVE.md`
3. Keep this review separate from Facility PIA drafting and runtime remediation.
4. The eight lanes are controlled generic threads, not activated ES-RA agents.
5. The review is documentary only. Implementation and execution remain unauthorized.
