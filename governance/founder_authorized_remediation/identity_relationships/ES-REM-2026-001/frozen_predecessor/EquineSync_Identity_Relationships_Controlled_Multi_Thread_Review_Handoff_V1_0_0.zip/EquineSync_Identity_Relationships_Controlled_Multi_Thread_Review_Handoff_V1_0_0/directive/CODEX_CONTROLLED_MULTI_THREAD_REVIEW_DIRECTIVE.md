# EQUINESYNC FOUNDER DIRECTIVE

## CONTROLLED MULTI-THREAD IDENTITY AND RELATIONSHIPS RATIFICATION-READINESS REVIEW

Directive ID: `ES-FORA-DIR-CMT-IDENTITY-RELATIONSHIPS-REVIEW-V1.0`

Founder: Rian Ray

Authorization mode: `CONTROLLED_MULTI_THREAD_REVIEW_ORCHESTRATION_MODE`

Authorization status: `AUTHORIZED_AVAILABLE_NOT_STARTED_PENDING_SCOPED_REVIEW_DIRECTIVE`

Authorization branch: `codex/founder-review-agent-runtime-requalification-v1`

Authorization commit: `75c56ac67b0de694436c093fc2dc5ff5dffe4ff3`

Custom-agent activation: `0/8`

F-0001: `OPEN_BLOCKING`

Implementation, execution, merge, release, deployment, and production: `UNAUTHORIZED`

External assurance: `NOT_EXTERNALLY_ASSURED`

# 1. Purpose

Conduct one bounded, segregated, documentary review of the frozen Identity and
Relationships design packages using eight separate controlled Codex threads or
isolated worktrees.

This is a temporary non-agent fallback. No lane may be represented as an
activated `ES-RA-*` agent.

The review shall determine whether the exact Identity and Relationships formal
ADR texts and cross-domain contracts are ready for Founder ratification.

Do not implement the reviewed designs.

# 2. Frozen review object

Verify the exact bytes included in this handoff ZIP before review.

Identity:
- Identity PIA V1.1.0 controlled revision
- expected SHA-256:
  `34dc47aa358d8d515186f2ed082b9c54e2ed351c6e02e55fb20163cf3137ff9b`

Relationships:
- Relationships PIA V1.1.0 revised candidate
- ADR Recommendations V1.0.0
- Controlled Sequence V1.0.0
- expected Controlled Sequence SHA-256:
  `a03a805426ea8bb6c7b50179a4c594a21b242fcb5a6a79dfe57dd503afdec634`
- Pre-Ratification Completion V1.0.0
- expected Pre-Ratification SHA-256:
  `25ca5031ec9b26780c291d4a56f97bd74bb92e42d7c0b20ce39a869056740b2d`

Supporting authority:
- immutable governance baseline:
  `acb518ea5a160820e64681ff95a16b010fe1156c`
- Stage 2A Founder-closure commit:
  `56dc68ce761b84800caa60997af7fb62ab34f82d`
- controlled-thread authorization commit:
  `75c56ac67b0de694436c093fc2dc5ff5dffe4ff3`

If any frozen input is missing, altered, or unverifiable, stop with:
`CONTROLLED_MULTI_THREAD_REVIEW_BLOCKED_BY_INPUT_INTEGRITY_FAILURE`

# 3. Scope

In scope:
- Identity PIA V1.1.0 and ADR-IDENTITY-001 through ADR-IDENTITY-007
- Relationships PIA V1.1.0, REL-FD-001 through REL-FD-016, and ADR-REL-001 through ADR-REL-007
- Founder-decision and recommendation traceability
- Identity-to-Relationships, Identity-to-Authorization,
  Identity-to-Protected-Participant, and Relationships-to-Authorization contracts
- source reconciliation
- documentary golden paths
- adversarial scenarios
- cross-PIA alignment
- MIAP terminology integrity
- ratification readiness

Out of scope:
- code, schemas, migrations, application or database startup
- product workflows, production, providers, GP-05
- Facility or Authorization PIA drafting
- baseline freeze, implementation authorization, F-0001 closure
- PR, merge, tag, release, or deployment

# 4. Eight independent lanes

Create exactly eight isolated lanes with unique IDs, separate prompts, separate
output directories, runtime provenance, timestamps, and checksums.

`CMT-01` Evidence Custody and Input Integrity
- verify bytes, hashes, manifests, commits, authority, lifecycle, and sources
- make no semantic ratification recommendation

`CMT-02` Identity Domain Review
- review Identity PIA and seven Identity ADRs
- may not approve its own redlines

`CMT-03` Relationships Domain Review
- review Relationships PIA, sixteen Founder decisions, and seven ADRs
- may not approve its own redlines

`CMT-04` Independent Conformance and Traceability
- independently compare all fourteen ADRs with approved decisions and recommendations
- do not rely solely on CMT-02 or CMT-03

`CMT-05` Adversarial Challenge
- test authority inflation, identity/relationship merge, recovery authority,
  hidden human actor, delegation excess, cycles, stale revocation, offline risk,
  guardian inflation, privacy enumeration, universal verification, unsafe
  migration, and MAIP drift
- complete first pass before seeing proposed redlines

`CMT-06` Machine Validation
- validate IDs, CSV, JSON, manifests, hashes, references, coverage, parity,
  duplicate identifiers, and frozen-input integrity

`CMT-07` Documentary Golden-Path Reproduction
- Identity: invitation, public signup, passkey/MFA, recovery, support,
  protected-account transition, duplicate identity
- Relationships: multi-location trainer, horse-care delegation, guardians,
  horse transfer, provisional claim, offline delegation plus revocation
- no application execution

`CMT-08` Segregated Synthesis and Proposed Redlines
- start only after CMT-01 through CMT-07 finish
- preserve dissent
- create redlines only where independently supported
- recommend ratification only with no open P0 or P1

No lane may edit another lane's output. No lane may claim custom-agent identity.
No lane may commit or push independently.

# 5. Classification

Use exactly:
`EXACTLY_ALIGNED`
`EDITORIAL_ONLY`
`CLARIFICATION_WITHIN_APPROVED_AUTHORITY`
`MATERIAL_ADDITION_REQUIRING_FOUNDER_DECISION`
`CONTROL_WEAKENING`
`CROSS_DOMAIN_CONFLICT`
`UNAUTHORIZED_IMPLEMENTATION_DECISION`
`SOURCE_GAP`
`MISSING_TRACEABILITY`
`TERMINOLOGY_DRIFT`
`AMBIGUOUS_REQUIRES_REMEDIATION`

Severity:
- P0: constitutional, authority, safeguarding, privacy, or evidence failure
- P1: material ambiguity, missing control, source/traceability/contract error
- P2: nonblocking editorial or later implementation parameter

No open P0 or P1 is permitted for ratification readiness.

# 6. Required deliverables

Create:
1. CONTROLLED_THREAD_REVIEW_PLAN.md
2. CONTROLLED_THREAD_REVIEW_PLAN.json
3. FROZEN_INPUT_INTEGRITY_REPORT.md
4. FROZEN_INPUT_INTEGRITY_REPORT.json
5. LANE_EXECUTION_AND_SEGREGATION_REGISTER.csv
6. THREAD_RUNTIME_PROVENANCE_REGISTER.csv
7. REVIEW_EVIDENCE_INDEX.csv
8. IDENTITY_FOUNDER_DECISION_TO_ADR_TRACEABILITY.csv
9. IDENTITY_ADR_CONFORMANCE_MATRIX.csv
10. IDENTITY_FORMAL_ADR_SEMANTIC_REVIEW.md
11. IDENTITY_FORMAL_ADR_SEMANTIC_REVIEW.json
12. IDENTITY_CONTRACT_REVIEW.md
13. IDENTITY_SOURCE_RECONCILIATION_DELTA.csv
14. IDENTITY_GOLDEN_PATH_RESULTS.csv
15. IDENTITY_ADVERSARIAL_RESULTS.csv
16. IDENTITY_RATIFICATION_RECOMMENDATION.md
17. IDENTITY_RATIFICATION_RECOMMENDATION.json
18. RELATIONSHIPS_FOUNDER_DECISION_TO_ADR_TRACEABILITY.csv
19. RELATIONSHIPS_ADR_CONFORMANCE_MATRIX.csv
20. RELATIONSHIPS_FORMAL_ADR_SEMANTIC_REVIEW.md
21. RELATIONSHIPS_FORMAL_ADR_SEMANTIC_REVIEW.json
22. RELATIONSHIPS_CONTRACT_REVIEW.md
23. RELATIONSHIPS_SOURCE_RECONCILIATION_DELTA.csv
24. RELATIONSHIPS_GOLDEN_PATH_RESULTS.csv
25. RELATIONSHIPS_ADVERSARIAL_RESULTS.csv
26. RELATIONSHIPS_RATIFICATION_RECOMMENDATION.md
27. RELATIONSHIPS_RATIFICATION_RECOMMENDATION.json
28. IDENTITY_RELATIONSHIPS_CROSS_PIA_ALIGNMENT.md
29. IDENTITY_RELATIONSHIPS_CROSS_PIA_ALIGNMENT.csv
30. OPEN_FINDINGS_AND_DECISIONS_REGISTER.csv
31. PROPOSED_REDLINE_REGISTER.csv
32. corrected ADR files only where objectively required
33. AS_DESIGNED_BASELINE_FREEZE_READINESS.md
34. IMPLEMENTATION_AUTHORIZATION_PRECHECK.md
35. NON_AGENT_FALLBACK_ATTESTATION.md
36. NON_IMPLEMENTATION_ATTESTATION.md
37. FINAL_FOUNDER_ACTION_MEMO.md
38. FINAL_FOUNDER_ACTION_MEMO.json
39. PACKAGE_FILE_MANIFEST.json
40. SHA256SUMS.txt
41. VALIDATION_REPORT.md
42. VALIDATION_REPORT.json

# 7. Git authority

Create review branch:
`codex/identity-relationships-controlled-thread-review-v1`

Record the exact base commit. Preserve the handoff ZIP externally and read-only.

Authorized:
- isolated worktrees or controlled threads
- documentary review, validation, adversarial analysis, golden paths, redlines
- one final review-package commit and push to the named branch

Not authorized:
- PR, merge, tag, release, deployment
- any custom-agent activation claim
- alteration of frozen inputs or fallback authorization
- F-0001 closure
- implementation or execution

# 8. Final disposition

Return exactly one:
- `IDENTITY_AND_RELATIONSHIPS_FORMAL_ADRS_READY_FOR_FOUNDER_RATIFICATION_UNDER_CONTROLLED_THREAD_REVIEW`
- `IDENTITY_READY_RELATIONSHIPS_REQUIRE_BOUNDED_REMEDIATION`
- `RELATIONSHIPS_READY_IDENTITY_REQUIRE_BOUNDED_REMEDIATION`
- `IDENTITY_AND_RELATIONSHIPS_REQUIRE_BOUNDED_REMEDIATION`
- `CONTROLLED_MULTI_THREAD_REVIEW_BLOCKED_BY_INPUT_INTEGRITY_FAILURE`
- `CONTROLLED_MULTI_THREAD_REVIEW_BLOCKED_BY_SEGREGATION_FAILURE`

Do not declare custom-agent activation, F-0001 closure, execution readiness,
implementation completion, production readiness, or enrollment readiness.

# 9. Final response

Report:
- handoff ZIP SHA-256
- review branch and base commit
- all lane IDs and runtime provenance
- lane completion and segregation results
- Identity and Relationships ADR dispositions
- cross-PIA alignment
- P0/P1/P2 counts
- source and contract gaps
- redlines
- frozen-input modifications, which must be zero
- custom agents executed, which must be zero
- commit and push
- final disposition
- exact recommended Founder action
