# Controlled Multi-Thread Authorization Context

- Status: `AUTHORIZED_AVAILABLE_NOT_STARTED_PENDING_SCOPED_REVIEW_DIRECTIVE`
- Branch: `codex/founder-review-agent-runtime-requalification-v1`
- Commit: `75c56ac67b0de694436c093fc2dc5ff5dffe4ff3`
- ES-RA activation: `0/8`
- F-0001: `OPEN_BLOCKING`
- Runtime limitation: `UNRESOLVED`
- Review threads launched at authorization: `0`
- Implementation, execution, release, and production: `UNAUTHORIZED`

Verify the repository authorization records directly. This file is context,
not replacement evidence.
