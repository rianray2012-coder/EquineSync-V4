## A
same
## B
same
