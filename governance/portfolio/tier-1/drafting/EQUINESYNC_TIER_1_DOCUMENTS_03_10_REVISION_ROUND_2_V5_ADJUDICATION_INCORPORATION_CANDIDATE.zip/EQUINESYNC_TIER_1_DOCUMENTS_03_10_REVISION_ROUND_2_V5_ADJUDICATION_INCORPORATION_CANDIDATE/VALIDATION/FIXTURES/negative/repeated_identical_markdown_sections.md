## A
same

## B
same
