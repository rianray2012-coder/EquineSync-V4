#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MATRIX = ROOT/'02_OPC_ROW_LEVEL_TRACEABILITY_MATRIX.csv'
SOURCE = ROOT/'05_OPC_TRACEABILITY_SOURCE_CONTROL_REGISTER.csv'
DEPS = ROOT/'06_OPC_DEPENDENCY_REGISTER.csv'
WPS = ROOT/'07_OPC_WORK_PACKAGE_REGISTER.csv'
RISKS = ROOT/'08_OPC_RISK_REGISTER.csv'
FINDINGS = ROOT/'09_OPC_FINDING_TREATMENT_REGISTER.csv'
OUT = ROOT/'11_OPC_TRACEABILITY_VALIDATION_REPORT.json'

required_columns = [
'requirement_id','requirement_statement','source_pia_id','source_document','source_document_sha256','source_location','founder_decision_ids','external_source_ids','external_source_resolution','external_source_hashes_known','actor','action','resource','workflow_ids','entity_or_field_ids','state_ids','permission_ids','interface_or_ui_ids','acceptance_criteria_ids','test_ids','evidence_ids','work_package_ids','dependency_ids','risk_ids','finding_ids','deviation_ids','release_classification','gate','mapping_method','mapping_status']

def refs(text,prefix):
    return set(re.findall(rf'{re.escape(prefix)}-\d{{3}}', text or ''))

def read_ids(path, col):
    with path.open(encoding='utf-8', newline='') as f:
        return {r[col] for r in csv.DictReader(f)}

checks=[]; warnings=[]; errors=[]
with MATRIX.open(encoding='utf-8', newline='') as f:
    reader=csv.DictReader(f); rows=list(reader); fields=reader.fieldnames or []
checks.append({'check':'required_columns','pass':all(c in fields for c in required_columns),'detail':f'{len(fields)} columns'})
missing_cols=[c for c in required_columns if c not in fields]
if missing_cols: errors.append(f'Missing columns: {missing_cols}')
checks.append({'check':'row_count_84','pass':len(rows)==84,'detail':len(rows)})
ids=[r.get('requirement_id','') for r in rows]
expected=[f'OPC-REQ-{i:03d}' for i in range(1,85)]
checks.append({'check':'sequential_unique_requirement_ids','pass':ids==expected and len(set(ids))==84,'detail':ids[:2]+ids[-2:]})
blank=[]
for i,r in enumerate(rows,2):
    for c in required_columns:
        if not str(r.get(c,'')).strip(): blank.append(f'row {i} {c}')
checks.append({'check':'no_blank_required_cells','pass':not blank,'detail':blank[:20]})
if blank: errors.extend(blank[:20])
checks.append({'check':'source_sha256_format','pass':all(re.fullmatch(r'[0-9a-f]{64}',r['source_document_sha256']) for r in rows),'detail':'all rows'})
checks.append({'check':'source_hash_consistent','pass':len({r['source_document_sha256'] for r in rows})==1,'detail':sorted({r['source_document_sha256'] for r in rows})})

source_ids=read_ids(SOURCE,'source_id'); dep_ids=read_ids(DEPS,'dependency_id'); wp_ids=read_ids(WPS,'work_package_id'); risk_ids=read_ids(RISKS,'risk_id'); finding_ids=read_ids(FINDINGS,'finding_id')
unknown={'sources':set(),'dependencies':set(),'work_packages':set(),'risks':set(),'findings':set()}
for r in rows:
    unknown['sources'] |= refs(r['external_source_ids'],'OPC-SRC')-source_ids
    unknown['dependencies'] |= refs(r['dependency_ids'],'OPC-DEP')-dep_ids
    unknown['work_packages'] |= refs(r['work_package_ids'],'OPC-WP')-wp_ids
    unknown['risks'] |= refs(r['risk_ids'],'OPC-RISK')-risk_ids
    unknown['findings'] |= refs(r['finding_ids'],'OPC-FIND-P1')-finding_ids
checks.append({'check':'all_references_resolve_to_package_registers','pass':all(not v for v in unknown.values()),'detail':{k:sorted(v) for k,v in unknown.items()}})
if any(unknown.values()): errors.append(f'Unknown refs: {unknown}')
checks.append({'check':'every_requirement_maps_to_traceability_finding','pass':all('OPC-FIND-P1-006' in r['finding_ids'] for r in rows),'detail':'84/84'})
checks.append({'check':'no_implementation_authority_claim','pass':all('AUTHORIZED' not in r['mapping_status'] for r in rows),'detail':'mapping status remains documentary'})

# Forward/backward counts
catalogs={'sources':source_ids,'dependencies':dep_ids,'work_packages':wp_ids,'risks':risk_ids,'findings':finding_ids}
used={k:set() for k in catalogs}
for r in rows:
    used['sources'] |= refs(r['external_source_ids'],'OPC-SRC')
    used['dependencies'] |= refs(r['dependency_ids'],'OPC-DEP')
    used['work_packages'] |= refs(r['work_package_ids'],'OPC-WP')
    used['risks'] |= refs(r['risk_ids'],'OPC-RISK')
    used['findings'] |= refs(r['finding_ids'],'OPC-FIND-P1')
coverage={k:{'catalog_count':len(catalogs[k]),'used_count':len(used[k]),'unused':sorted(catalogs[k]-used[k])} for k in catalogs}
checks.append({'check':'forward_backward_catalog_coverage_computed','pass':True,'detail':coverage})

# Retained source-freeze warning is deliberate and is not an OPC-REV-006 matrix-structure failure.
with SOURCE.open(encoding='utf-8', newline='') as f:
    unresolved=[r['source_id'] for r in csv.DictReader(f) if r['verification_posture'] not in ('REGISTERED_IMMUTABLE','EXACT_HASH_REGISTERED')]
if unresolved:
    warnings.append({'code':'RETAINED_SOURCE_ACCESSION_CONDITION','detail':unresolved,'related_finding':'OPC-FIND-P1-001'})
warnings.append({'code':'FOUNDER_EXECUTION_REQUIRED','detail':'Candidate closure is not effective until the Founder executes the exact disposition.'})
warnings.append({'code':'NON_INDEPENDENT_REVIEW','detail':'Validation is deterministic and procedurally separated, not independent external assurance.'})

overall='PASS_WITH_RETAINED_NON_OPC_REV_006_CONDITIONS' if not errors else 'FAIL'
report={'schema_version':'1.0.0','overall':overall,'target_finding':'OPC-REV-006','current_finding_alias':'OPC-FIND-P1-006','candidate_closure':'CLOSED_WITH_ROW_LEVEL_MACHINE_TRACEABILITY_EVIDENCE_PENDING_FOUNDER_EXECUTION','checks':checks,'warnings':warnings,'errors':errors,'metrics':{'requirements':len(rows),'columns':len(fields),'source_catalog':len(source_ids),'dependency_catalog':len(dep_ids),'work_package_catalog':len(wp_ids),'risk_catalog':len(risk_ids),'finding_catalog':len(finding_ids)}}
OUT.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'overall':overall,'report':str(OUT),'errors':errors},indent=2))
sys.exit(0 if not errors else 1)
