Synthetic control status: FAIL.
