Synthetic control status: PASS.
