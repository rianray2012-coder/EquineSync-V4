# Document 08 - Source Provenance Authority And Supersession Reconciliation

Readiness determination: `REVISION_ROUND_2_REMEDIATION_IN_PROGRESS_CONTENT_REVISION_REQUIRED`.

Authority boundary: `NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED`.

The source register now populates `duplicate_cluster_id` for duplicate cluster members and uses `NO_DUPLICATE_CLUSTER` for singleton rows. Dashboard counts distinguish unique hashes, duplicate clusters, redundant duplicate copies, and cluster-member rows.

Rows that contain adoption or lock evidence are labelled as source evidence only. They do not alter this package's `NOT_ADOPTED` state.

## Definitions

Source authority is the documentary status assigned to an input source inside `SOURCE_AUTHORITY_DISPOSITION_REGISTER.csv`. Supersession is a recorded relationship where one source may replace, narrow, or qualify another source, subject to evidence. A duplicate cluster groups records that share the same source content or custody relationship. `NO_DUPLICATE_CLUSTER` marks singleton rows that are not members of a duplicate cluster.

## Acceptance Criteria For This Register

A source row is adequate only when the source identity, custody/evidence locator, authority label, duplicate-cluster treatment, supersession status, and candidate-path treatment are readable. A source with adoption or lock language remains source evidence only unless a separate current package authority record changes package state.

## Register-Backed Example

Duplicate-cluster rows and singleton rows are counted separately in `SOURCE_DISPOSITION_DASHBOARD.csv`. A duplicate cluster may explain redundant copies, but it does not decide which source controls future implementation unless the source authority register and Founder decision evidence expressly support that conclusion.

## Edge Cases

Hash-identical files can still require custody review if their source role differs. Historical lock evidence does not adopt this package. Conflicting candidate paths, missing source authority, or unresolved supersession relationships must remain advisory or retained open rather than silently becoming controlling sources.

## Dependencies

This document depends on `SOURCE_AUTHORITY_DISPOSITION_REGISTER.csv`, `SOURCE_AUTHORITY_DISPOSITION_REGISTER.json`, `DUPLICATE_COUNTERPART_CLUSTER_REGISTER.csv`, `SOURCE_DISPOSITION_DASHBOARD.csv`, and the package custody records in `00_PROGRAM_CONTROL/`.

## V4 Purpose Scope Method And Limitations

Purpose: provide a reviewer-readable control surface for source reconciliation without creating adoption, activation, implementation, production, merge, certification, waiver, risk-acceptance, final-closure, or Founder-approval authority.

Scope: limited to the V4 bounded rereview package, the registers in this directory, authenticated source-review inputs, and the PR #90 documentary custody context.

Method: source custody, candidate-path handling, duplicate clusters, and authority labels. Reviewers should read register rows by row ID, source locator, evidence hash or byte count where present, status vocabulary, and retained-open fields. Blank, generic, or repeated analytical text is not closure evidence.

Limitations: this document is not a runtime assessment, legal opinion, production deployment record, certification report, or Founder decision. Open T1C rows remain open until independently adjudicated.

Evidence boundary: every conclusion must link to a package file, register row, source-review finding ID, validation report, or detached archive checksum. Absence of evidence must be recorded as open rather than inferred as remediated.
