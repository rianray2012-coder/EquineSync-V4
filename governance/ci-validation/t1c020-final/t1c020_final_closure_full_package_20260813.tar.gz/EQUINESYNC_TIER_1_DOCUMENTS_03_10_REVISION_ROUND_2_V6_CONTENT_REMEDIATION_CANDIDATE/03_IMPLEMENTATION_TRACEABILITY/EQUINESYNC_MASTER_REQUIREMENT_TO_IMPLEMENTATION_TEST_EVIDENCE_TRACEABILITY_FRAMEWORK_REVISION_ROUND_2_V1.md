# Document 03 - Source-Text Candidate To Requirement Traceability Framework

Readiness determination: `REVISION_ROUND_2_REMEDIATION_IN_PROGRESS_CONTENT_REVISION_REQUIRED`.

Authority boundary: `NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED`.

This document intentionally does **not** claim that the 96 rows in `REQUIREMENT_TRACEABILITY_REGISTER.csv` are accepted requirements. After external review, every row is typed `SOURCE_TEXT_CANDIDATE` until a row-level ISO/IEC/IEEE 29148 characteristic review is performed and recorded.

## Method

`discovery_method` records how a candidate was found. `verification_method` remains `NOT_PERFORMED` unless an actual requirement review, implementation review, or test/assertion review is completed. Candidate paths, candidate test files, and keyword matches are evidence-discovery aids only.

## Trace State

Bidirectional traceability, parent/child requirement links, and design-artifact tiers are explicitly `NOT_ESTABLISHED`. Verified coverage is `0%`.

## Example

`T1R2-REQ-0001` is preserved as source text candidate evidence. It is not accepted as a normative requirement and cannot support implementation, test, or coverage closure.

## Definitions

`SOURCE_TEXT_CANDIDATE` means source text retained for later requirement-quality review. It is not a normative requirement until row-level acceptance evidence is recorded. `REJECTED_SOURCE_FRAGMENT_NOT_REQUIREMENT` means the fragment is preserved in quarantine because it was reviewed as non-requirement material. `verification_method=NOT_PERFORMED` means no implementation, test, or ISO/IEC/IEEE 29148 characteristic review has been completed for that row.

## Acceptance Criteria For This Register

A row can support documentary traceability only when its row ID, source locator, evidence status, and classification are readable in `REQUIREMENT_TRACEABILITY_REGISTER.csv`. A row cannot support requirement acceptance, implementation coverage, test closure, or production-readiness claims unless a future authorized review records the required characteristic review and acceptance evidence. Coverage metrics must reconcile to the accepted, candidate, and quarantined populations rather than treating all discovered text as requirements.

## Edge Cases

Candidate file paths, keyword matches, and test-file references are discovery signals only. Quarantined fragments remain preserved evidence and must not be deleted or counted as accepted requirements. A coverage count is not proof of implementation coverage when the underlying rows remain candidates. Conflicts between source text, candidate paths, and validation outputs must be retained open rather than resolved by inference.

## Dependencies

This document depends on `REQUIREMENT_TRACEABILITY_REGISTER.csv`, `NON_REQUIREMENT_SOURCE_FRAGMENT_QUARANTINE.csv`, `COVERAGE_METRICS_BY_DOMAIN.csv`, `TRACEABILITY_MODEL.json`, and `DOC03_V5_COVERAGE_RECONCILIATION.md`. T1C-006 evidence controls whether candidate rows stay open, become rejected, or later receive authorized requirement acceptance.

## V4 Purpose Scope Method And Limitations

Purpose: provide a reviewer-readable control surface for implementation traceability without creating adoption, activation, implementation, production, merge, certification, waiver, risk-acceptance, final-closure, or Founder-approval authority.

Scope: limited to the V4 bounded rereview package, the registers in this directory, authenticated source-review inputs, and the PR #90 documentary custody context.

Method: source-text candidate discovery and non-normative requirement handling. Reviewers should read register rows by row ID, source locator, evidence hash or byte count where present, status vocabulary, and retained-open fields. Blank, generic, or repeated analytical text is not closure evidence.

Limitations: this document is not a runtime assessment, legal opinion, production deployment record, certification report, or Founder decision. Open T1C rows remain open until independently adjudicated.

Evidence boundary: every conclusion must link to a package file, register row, source-review finding ID, validation report, or detached archive checksum. Absence of evidence must be recorded as open rather than inferred as remediated.


## V5 Doc03 Candidate And Quarantine Reconciliation

V5 records a split population: 45 surviving `SOURCE_TEXT_CANDIDATE` rows and 51 `REJECTED_SOURCE_FRAGMENT_NOT_REQUIREMENT` rows retained in quarantine. The surviving candidates remain `NOT_ACCEPTED_AS_REQUIREMENT`; ISO 29148 checks remain `NOT_PERFORMED`; T1C-006 remains open.
