#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_T1C019_BOUNDARY_REMEDIATED_RETAINED_OPEN"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def run_json(script, package, output_name):
    output = package.parent / output_name
    result = subprocess.run(
        [sys.executable, str(script), "--package-root", str(package), "--json-output", str(output)],
        text=True,
        capture_output=True,
    )
    return result, json.loads(output.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v12_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v12_t1c016_closure.py"
    v12, v12_report = run_json(v12_script, package, "v12_validation_for_v13_t1c019_boundary.json")
    v12_failed = [r["check"] for r in v12_report.get("checks", []) if r.get("status") != "PASS"]
    failures += add(
        checks,
        "v12_only_stale_blocked_row_count_expectation_failure",
        v12.returncode == 1
        and v12_report.get("failures") == 1
        and v12_failed == ["t1c016_removed_from_blocked_retained_open_register"],
        f"v12_status={v12_report.get('status')} failures={v12_report.get('failures')} failed_checks={v12_failed}",
    )

    reg = rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    by_id = {row["t1c_id"]: row for row in reg}
    t1c016 = by_id.get("T1C-016", {})
    failures += add(
        checks,
        "t1c016_still_final_closed_only",
        t1c016.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_016_ONLY"
        and t1c016.get("current_target_disposition") == "PATRICK_SECOND_REVIEWER_ACCEPTED_FINAL_CLOSURE_T1C_016_ONLY"
        and t1c016.get("merge_effect") == "MERGE_NOT_AUTHORIZED"
        and "PACKAGE_FINAL_CLOSURE" in t1c016.get("authority_effect", ""),
        json.dumps(t1c016, sort_keys=True),
    )

    t1c019 = by_id.get("T1C-019", {})
    failures += add(
        checks,
        "t1c019_retained_open_boundary_remediated",
        t1c019.get("current_target_disposition") == "OPEN_RETAINED_REMEDIATED_FOR_NON_FABRICATION_PENDING_CONTROL_SPECIFICITY_AND_AUTHORIZED_REVIEW"
        and t1c019.get("closure_state") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and t1c019.get("second_reviewer_state") == "NOT_PERFORMED_NOT_FABRICATED_T1C_019_PATRICK_T1C_016_ACCEPTANCE_NOT_GENERALIZED"
        and t1c019.get("authority_effect") == "T1C_019_RETAINED_OPEN_NO_APPOINTMENT_NO_PERFORMED_SECOND_REVIEW_NO_CERTIFICATION_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
        and t1c019.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c019, sort_keys=True),
    )

    ev = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")}
    t1c019_ev = ev.get("T1C-019", {})
    failures += add(
        checks,
        "t1c019_per_finding_evidence_retained_open",
        t1c019_ev.get("closure_assertion") == "NOT_CLOSED_CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and "Patrick T1C-016 acceptance remains T1C-016-only" in t1c019_ev.get("remaining_open_item", "")
        and "T1C-019_TASK_ITEM_4_BOUNDARY_LANGUAGE_REMEDIATION.md" in t1c019_ev.get("evidence_locator", ""),
        json.dumps(t1c019_ev, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    blocked_text = [" ".join(row.values()) for row in blocked]
    failures += add(
        checks,
        "t1c019_specific_blocked_row_present_and_t1c016_absent",
        any("T1C-019 second-reviewer appointment/performance boundary" in text for text in blocked_text)
        and not any("T1C-016" in row.get("blocked_item", "") for row in blocked),
        f"blocked_rows={len(blocked)}",
    )

    doc07 = (package / "07_OWNERSHIP_STEWARDSHIP_REVIEW" / "EQUINESYNC_GOVERNANCE_OWNERSHIP_ACCOUNTABILITY_AND_REVIEW_CALENDAR_REVISION_ROUND_2_V1.md").read_text(encoding="utf-8")
    required_doc07 = [
        "## T1C-019 Second Reviewer Boundary",
        "T1C-016 finding-only closure",
        "does not appoint him as package-wide second reviewer",
        "does not close T1C-019",
        "T1C-019 remains open",
        "do not create appointment authority",
    ]
    failures += add(
        checks,
        "doc07_t1c019_boundary_language_present",
        all(token in doc07 for token in required_doc07),
        json.dumps([token for token in required_doc07 if token not in doc07]),
    )

    forbidden = [
        "T1C-019 final closure",
        "T1C-019 is closed",
        "package-wide second reviewer appointed",
        "second-reviewer completion for T1C-019",
        "certification completion for T1C-019",
    ]
    combined = "\n".join([
        doc07,
        json.dumps(t1c019, sort_keys=True),
        json.dumps(t1c019_ev, sort_keys=True),
        "\n".join(blocked_text),
    ])
    failures += add(
        checks,
        "no_t1c019_forbidden_completion_claims",
        not any(token in combined for token in forbidden),
        json.dumps([token for token in forbidden if token in combined]),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
