#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_T1C003_NO_IMPLIED_RISK_ACCEPTANCE"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v9_json = package.parent / "v9_validation_for_v10_t1c003.json"
    v9_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v9_closure_aware.py"
    v9 = subprocess.run(
        [sys.executable, str(v9_script), "--package-root", str(package), "--json-output", str(v9_json)],
        text=True,
        capture_output=True,
    )
    v9_report = json.loads(v9_json.read_text(encoding="utf-8"))
    failures += add(
        checks,
        "v9_closure_aware_validator_passes",
        v9.returncode == 0 and v9_report.get("failures") == 0,
        f"v9_status={v9_report.get('status')} failures={v9_report.get('failures')}",
    )

    decisions = rows(package / "05_FOUNDER_DECISION_REGISTER" / "FOUNDER_DECISION_DISPOSITION_REGISTER.csv")
    failures += add(
        checks,
        "founder_decision_register_no_selected_dispositions",
        all(
            row.get("exact_decision_text") == "NO_FOUNDER_DECISION_RECORDED_IN_THIS_PACKAGE"
            and row.get("selected_disposition") == "NO_DISPOSITION_SELECTED"
            and row.get("recommended_option") == "NO_RECOMMENDATION_SELECTED"
            and row.get("accepted_risks") == "NONE_ACCEPTED_BY_THIS_PACKAGE"
            and row.get("authority_granted") == "NONE_BY_THIS_PACKAGE"
            and row.get("implementation_effect") == "NONE"
            and row.get("activation_effect") == "NONE"
            for row in decisions
        ),
        f"decision_rows={len(decisions)}",
    )

    fd004 = next((row for row in decisions if row.get("decision_id") == "FD-T1R2-004"), {})
    failures += add(
        checks,
        "fd_t1r2_004_no_risk_acceptance_recorded",
        fd004.get("accepted_risks") == "NONE_ACCEPTED_BY_THIS_PACKAGE"
        and fd004.get("selected_disposition") == "NO_DISPOSITION_SELECTED"
        and fd004.get("authority_granted") == "NONE_BY_THIS_PACKAGE",
        json.dumps(fd004, sort_keys=True),
    )

    packet = rows(package / "FOUNDER_DECISION_PACKET.csv")
    failures += add(
        checks,
        "founder_decision_packet_decision_frames_only",
        all(
            row.get("decision_frame_only") == "YES"
            and row.get("recommended_option") == "NO_RECOMMENDATION_SELECTED"
            and row.get("authority_granted_by_approval") == "NONE_UNLESS_FUTURE_FOUNDER_TEXT_EXPRESSLY_GRANTS_IT"
            and row.get("implementation_effect") == "NONE"
            and row.get("activation_effect") == "NONE"
            for row in packet
        ),
        f"packet_rows={len(packet)}",
    )

    packet_fd004 = next((row for row in packet if row.get("decision_id") == "FD-T1R2-004"), {})
    failures += add(
        checks,
        "fd_t1r2_004_packet_disclaims_implied_acceptance",
        "no residual risk, waiver, exception, closure, or external-finding exclusion is accepted unless future Founder text expressly identifies the row and grants that authority"
        in packet_fd004.get("consequence_if_approved", "")
        and "EXTERNAL_REVIEW/EXTERNAL_REVIEW_FINDING_DISPOSITION_REGISTER.csv" in packet_fd004.get("relevant_evidence", "")
        and "OUTSIDE_REVIEW/T1R2_EXT_TO_T1C_CURRENT_CROSSWALK.csv" in packet_fd004.get("relevant_evidence", ""),
        json.dumps(packet_fd004, sort_keys=True),
    )

    doc06 = rows(package / "06_FINDINGS_RISKS_EXCEPTIONS_WAIVERS" / "FINDINGS_RISKS_EXCEPTIONS_WAIVERS_REGISTER.csv")
    failures += add(
        checks,
        "doc06_contains_findings_not_risk_acceptance_rows",
        len(doc06) == 9
        and all(row.get("record_classification") == "finding" for row in doc06)
        and all(row.get("accepted_risks") == "NONE_ACCEPTED_BY_THIS_PACKAGE" for row in doc06)
        and all(row.get("approving_authority") == "NOT_APPLICABLE" for row in doc06)
        and all(row.get("business_justification") == "NOT_APPLICABLE" for row in doc06)
        and all(row.get("compensating_controls") == "NOT_APPLICABLE" for row in doc06)
        and all(row.get("expiration_date") == "NOT_APPLICABLE" for row in doc06),
        f"doc06_rows={len(doc06)} classifications={sorted({row.get('record_classification') for row in doc06})}",
    )

    external = rows(package / "EXTERNAL_REVIEW" / "EXTERNAL_REVIEW_FINDING_DISPOSITION_REGISTER.csv")
    failures += add(
        checks,
        "external_review_findings_preserved_without_authority_elevation",
        len(external) == 28
        and {row.get("finding_id") for row in external} == {f"F-{i:02d}" for i in range(1, 29)}
        and all(row.get("authority_effect") == "NONE" for row in external)
        and all(row.get("merge_effect") == "MERGE_NOT_AUTHORIZED" for row in external),
        f"external_rows={len(external)}",
    )

    unresolved = rows(package / "UNRESOLVED_ISSUE_REGISTER.csv")
    external_issue_ids = {f"T1R2-EXT-F-{i:02d}" for i in range(1, 29)}
    present_issue_ids = {row.get("issue_id") for row in unresolved}
    failures += add(
        checks,
        "external_findings_remain_in_unresolved_issue_register",
        external_issue_ids.issubset(present_issue_ids),
        f"missing={sorted(external_issue_ids - present_issue_ids)}",
    )

    forbidden_exact = {
        "RISK_ACCEPTED",
        "RESIDUAL_RISK_ACCEPTED",
        "ACCEPTED_RESIDUAL_RISK",
        "WAIVER_APPROVED",
        "EXCEPTION_APPROVED",
        "FOUNDER_APPROVED",
        "MERGE_AUTHORIZED",
        "PRODUCTION_AUTHORIZED",
        "CERTIFICATION_COMPLETE",
        "ADOPTION_READY",
        "ACTIVATION_READY",
    }
    csv_claims = []
    checked_csvs = [
        "FOUNDER_DECISION_PACKET.csv",
        "05_FOUNDER_DECISION_REGISTER/FOUNDER_DECISION_DISPOSITION_REGISTER.csv",
        "06_FINDINGS_RISKS_EXCEPTIONS_WAIVERS/FINDINGS_RISKS_EXCEPTIONS_WAIVERS_REGISTER.csv",
        "EXTERNAL_REVIEW/EXTERNAL_REVIEW_FINDING_DISPOSITION_REGISTER.csv",
        "UNRESOLVED_ISSUE_REGISTER.csv",
        "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv",
    ]
    for rel in checked_csvs:
        for row_index, row in enumerate(rows(package / rel), start=2):
            for field, value in row.items():
                if (value or "").strip().upper() in forbidden_exact:
                    csv_claims.append(f"{rel}:{row_index}:{field}:{value}")
    failures += add(
        checks,
        "operative_csv_surfaces_no_forbidden_authority_tokens",
        not csv_claims,
        "claims=" + ",".join(csv_claims[:20]),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
