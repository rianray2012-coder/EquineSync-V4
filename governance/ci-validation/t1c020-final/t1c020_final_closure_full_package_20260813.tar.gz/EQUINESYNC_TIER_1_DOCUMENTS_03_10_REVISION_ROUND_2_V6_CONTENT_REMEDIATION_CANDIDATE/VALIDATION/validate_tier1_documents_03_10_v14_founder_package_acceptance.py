#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_WITH_RETAINED_OPEN_ITEMS"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    manifest = json.loads((package / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    failures += add(
        checks,
        "package_status_founder_accepted_retained_open",
        manifest.get("package_status") == EXPECTED_STATUS,
        manifest.get("package_status", ""),
    )

    record = package / "FOUNDER_PACKAGE_ACCEPTANCE_RECORD.md"
    record_text = record.read_text(encoding="utf-8") if record.exists() else ""
    required_record = [
        "FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_WITH_RETAINED_OPEN_ITEMS",
        "This is documentary package acceptance",
        "does not close retained-open findings",
        "T1C-019 is accepted as retained open",
        "does not authorize",
    ]
    failures += add(
        checks,
        "founder_package_acceptance_record_present",
        all(token in record_text for token in required_record),
        json.dumps([token for token in required_record if token not in record_text]),
    )

    reg = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")}
    t1c019 = reg.get("T1C-019", {})
    failures += add(
        checks,
        "t1c019_founder_accepted_retained_open_not_closed",
        t1c019.get("current_target_disposition") == "FOUNDER_ACCEPTED_RETAINED_OPEN_BOUNDARY_REMEDIATION_PACKAGE_ACCEPTANCE_T1C_019_NOT_CLOSED"
        and t1c019.get("closure_state") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_FOUNDER_ACCEPTED_RETAINED_OPEN"
        and t1c019.get("second_reviewer_state") == "NOT_PERFORMED_NOT_FABRICATED_T1C_019_PATRICK_T1C_016_ACCEPTANCE_NOT_GENERALIZED"
        and t1c019.get("authority_effect") == "T1C_019_FOUNDER_ACCEPTED_RETAINED_OPEN_BOUNDARY_REMEDIATION_ONLY_NO_APPOINTMENT_NO_PERFORMED_SECOND_REVIEW_NO_CERTIFICATION_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
        and t1c019.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c019, sort_keys=True),
    )

    ev = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")}
    t1c019_ev = ev.get("T1C-019", {})
    failures += add(
        checks,
        "t1c019_evidence_register_founder_accepted_retained_open",
        t1c019_ev.get("closure_assertion") == "NOT_CLOSED_FOUNDER_ACCEPTED_RETAINED_OPEN_BOUNDARY_REMEDIATION"
        and "FOUNDER_PACKAGE_ACCEPTANCE_RECORD.md" in t1c019_ev.get("evidence_locator", "")
        and "T1C-019 remains open after Founder package acceptance" in t1c019_ev.get("remaining_open_item", ""),
        json.dumps(t1c019_ev, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    t1c019_blocked = [row for row in blocked if row.get("blocked_item") == "T1C-019 second-reviewer appointment/performance boundary and ownership-control specificity final closure."]
    failures += add(
        checks,
        "t1c019_blocked_register_retained_after_founder_acceptance",
        len(t1c019_blocked) == 1
        and t1c019_blocked[0].get("retained_status") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and "Founder accepted and approved the documentary package" in t1c019_blocked[0].get("blocking_reason", ""),
        json.dumps(t1c019_blocked, sort_keys=True),
    )

    t1c016 = reg.get("T1C-016", {})
    failures += add(
        checks,
        "t1c016_final_closure_still_scoped_only",
        t1c016.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_016_ONLY"
        and "PACKAGE_FINAL_CLOSURE" in t1c016.get("authority_effect", ""),
        json.dumps(t1c016, sort_keys=True),
    )

    forbidden = [
        "ADOPTED_BY_FOUNDER",
        "ACTIVE_BY_FOUNDER",
        "IMPLEMENTATION_AUTHORIZED_BY_FOUNDER",
        "PRODUCTION_USE_AUTHORIZED_BY_FOUNDER",
        "MERGE_AUTHORIZED_BY_FOUNDER",
        "CERTIFICATION_COMPLETE_BY_FOUNDER",
        "RISK_ACCEPTED_BY_FOUNDER",
        "PACKAGE_FINAL_CLOSURE_GRANTED",
    ]
    current_surfaces = "\n".join(
        [
            json.dumps(manifest),
            record_text,
            json.dumps(t1c019),
            json.dumps(t1c019_ev),
            json.dumps(t1c019_blocked),
        ]
    )
    failures += add(
        checks,
        "no_forbidden_founder_acceptance_authority_elevation",
        not any(token in current_surfaces for token in forbidden),
        json.dumps([token for token in forbidden if token in current_surfaces]),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {"status": status, "failures": failures, "checks": checks}
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
