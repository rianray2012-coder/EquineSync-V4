#!/usr/bin/env python3
import argparse
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_T1C016_AUTHORITY_BOUNDARY_VALIDATED"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"

PRINCIPAL_DOCS = {
    "03": {
        "path": "03_IMPLEMENTATION_TRACEABILITY/EQUINESYNC_MASTER_REQUIREMENT_TO_IMPLEMENTATION_TEST_EVIDENCE_TRACEABILITY_FRAMEWORK_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["REQUIREMENT_TRACEABILITY_REGISTER.csv", "NON_REQUIREMENT_SOURCE_FRAGMENT_QUARANTINE.csv", "COVERAGE_METRICS_BY_DOMAIN.csv"],
    },
    "04": {
        "path": "04_AUTHORITY_LIFECYCLE_REGISTER/EQUINESYNC_AUTHORITY_LIFECYCLE_STATE_AND_TRANSITION_REGISTER_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Register-Backed Example",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["AUTHORITY_LIFECYCLE_MODEL.json", "LIFECYCLE_TRANSITION_MATRIX.csv", "INVALID_STATE_RULES.csv"],
    },
    "05": {
        "path": "05_FOUNDER_DECISION_REGISTER/EQUINESYNC_FOUNDER_DECISION_SCOPE_AUTHORITY_AND_DISPOSITION_REGISTER_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Register-Backed Example",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["FOUNDER_DECISION_DISPOSITION_REGISTER.csv", "FOUNDER_DECISION_PACKET.csv", "UNRESOLVED_ISSUE_REGISTER.csv"],
    },
    "06": {
        "path": "06_FINDINGS_RISKS_EXCEPTIONS_WAIVERS/EQUINESYNC_FINDINGS_RISKS_EXCEPTIONS_WAIVERS_AND_CLOSURE_CONTROL_REGISTER_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Register-Backed Example",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["FINDINGS_RISKS_EXCEPTIONS_WAIVERS_REGISTER.csv", "EXTERNAL_REVIEW_FINDING_DISPOSITION_REGISTER.csv", "UNRESOLVED_ISSUE_REGISTER.csv"],
    },
    "07": {
        "path": "07_OWNERSHIP_STEWARDSHIP_REVIEW/EQUINESYNC_GOVERNANCE_OWNERSHIP_ACCOUNTABILITY_AND_REVIEW_CALENDAR_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["OWNERSHIP_ACCOUNTABILITY_MATRIX.csv", "REVIEW_CALENDAR.csv", "VACANCY_AND_SUCCESSION_REGISTER.csv"],
    },
    "08": {
        "path": "08_SOURCE_RECONCILIATION/EQUINESYNC_SOURCE_PROVENANCE_AUTHORITY_AND_SUPERSESSION_RECONCILIATION_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Register-Backed Example",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["SOURCE_AUTHORITY_DISPOSITION_REGISTER.csv", "DUPLICATE_COUNTERPART_CLUSTER_REGISTER.csv", "SOURCE_DISPOSITION_DASHBOARD.csv"],
    },
    "09": {
        "path": "09_WORKSTREAM_PR_BRANCH_DISPOSITION/EQUINESYNC_OPEN_WORKSTREAM_PR_BRANCH_AND_EVIDENCE_DISPOSITION_REGISTER_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Register",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["WORKSTREAM_PR_BRANCH_DISPOSITION_REGISTER.csv", "WORKSTREAM_DISPOSITION_REPORT.md", "MERGE_NOT_AUTHORIZED"],
    },
    "10": {
        "path": "10_CLOSING_AUDIT_PROTOCOL/EQUINESYNC_GOVERNANCE_CLOSING_AUDIT_PROTOCOL_AND_BOUNDED_CERTIFICATION_PACKAGE_REVISION_ROUND_2_V1.md",
        "sections": [
            "## Definitions",
            "## Acceptance Criteria For This Protocol",
            "## Template-Backed Example",
            "## Edge Cases",
            "## Dependencies",
        ],
        "evidence": ["AUDIT_MODEL.json", "TEMPLATE_INDEX.csv", "TEMPLATE_PURPOSE_SPECIFICITY_EVIDENCE_TABLE.csv"],
    },
}

FORBIDDEN_EXACT_TOKENS = {
    "ADOPTION_READY",
    "ACTIVATION_READY",
    "IMPLEMENTATION_AUTHORIZED",
    "PRODUCTION_AUTHORIZED",
    "PRODUCTION_USE_AUTHORIZED",
    "MERGE_AUTHORIZED",
    "CERTIFICATION_COMPLETE",
    "CERTIFIED",
    "SECOND_REVIEWER_COMPLETE",
    "SECOND_REVIEW_COMPLETED",
    "RISK_ACCEPTED",
    "RESIDUAL_RISK_ACCEPTED",
    "WAIVER_APPROVED",
    "EXCEPTION_APPROVED",
    "FINAL_CLOSURE",
    "FINAL_CLOSED",
    "FOUNDER_APPROVED",
}

REQUIRED_NEGATIVE_PHRASES = [
    "does not",
    "not ",
    "must not",
    "cannot",
    "unless future",
    "requires express",
]


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def line_claims(text):
    claims = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        upper = line.upper()
        for token in FORBIDDEN_EXACT_TOKENS:
            if token in upper and token not in AUTHORITY_BOUNDARY:
                lower = line.lower()
                if not any(phrase in lower for phrase in REQUIRED_NEGATIVE_PHRASES):
                    claims.append(f"{line_number}:{token}:{line.strip()}")
    return claims


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v10_json = package.parent / "v10_validation_for_v11_t1c016.json"
    v10_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v10_t1c003_no_implied_risk_acceptance.py"
    v10 = subprocess.run(
        [sys.executable, str(v10_script), "--package-root", str(package), "--json-output", str(v10_json)],
        text=True,
        capture_output=True,
    )
    v10_report = json.loads(v10_json.read_text(encoding="utf-8"))
    failures += add(
        checks,
        "v10_no_implied_risk_acceptance_validator_passes",
        v10.returncode == 0 and v10_report.get("failures") == 0,
        f"v10_status={v10_report.get('status')} failures={v10_report.get('failures')}",
    )

    for doc_id, spec in PRINCIPAL_DOCS.items():
        rel = spec["path"]
        text = (package / rel).read_text(encoding="utf-8")
        failures += add(
            checks,
            f"doc{doc_id}_authority_boundary_present",
            AUTHORITY_BOUNDARY in text,
            rel,
        )
        missing_sections = [section for section in spec["sections"] if section not in text]
        failures += add(
            checks,
            f"doc{doc_id}_required_depth_sections_present",
            not missing_sections,
            f"missing={missing_sections}",
        )
        missing_evidence = [token for token in spec["evidence"] if token not in text]
        failures += add(
            checks,
            f"doc{doc_id}_package_evidence_dependencies_present",
            not missing_evidence,
            f"missing={missing_evidence}",
        )
        claims = line_claims(text)
        failures += add(
            checks,
            f"doc{doc_id}_no_forbidden_authority_elevation_claims",
            not claims,
            "claims=" + json.dumps(claims[:20]),
        )

    t1c016_outputs = [
        package.parent / "T1C-016_SCOPE_CONFIRMATION.md",
        package.parent / "T1C-016_TASK_ITEM_2_PRINCIPAL_DOCUMENT_BODY_INVENTORY.md",
        package.parent / "T1C-016_TASK_ITEM_3_DEPTH_GAP_TABLE.md",
        package.parent / "T1C-016_TASK_ITEM_4_DOCUMENT_DEPTH_REMEDIATION.md",
    ]
    failures += add(
        checks,
        "t1c016_task_evidence_artifacts_present",
        all(path.exists() for path in t1c016_outputs),
        "missing=" + json.dumps([str(path) for path in t1c016_outputs if not path.exists()]),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
