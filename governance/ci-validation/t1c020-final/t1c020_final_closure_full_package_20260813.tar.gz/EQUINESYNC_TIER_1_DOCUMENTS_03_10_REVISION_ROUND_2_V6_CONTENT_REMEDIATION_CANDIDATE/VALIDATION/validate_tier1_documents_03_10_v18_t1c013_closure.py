#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_T1C010_T1C013_T1C019_ASSIGNED_SECOND_REVIEWER_CLOSED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    manifest = json.loads((package / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    failures += add(checks, "package_status_records_t1c013_closure_without_package_final_closure", manifest.get("package_status") == EXPECTED_STATUS, manifest.get("package_status", ""))

    reg = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")}
    t1c013 = reg.get("T1C-013", {})
    expected_authority = "T1C_013_FINDING_FINAL_CLOSURE_ONLY_BY_ASSIGNED_SECOND_REVIEWER_NO_LIVE_PR_RELIANCE_NO_REBASE_NO_BRANCH_MUTATION_NO_CI_RERUN_NO_MERGE_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_CERTIFICATION_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
    failures += add(
        checks,
        "t1c013_final_closed_by_assigned_second_reviewer_only",
        t1c013.get("current_target_disposition") == "PATRICK_SECOND_REVIEWER_ACCEPTED_FINAL_CLOSURE_T1C_013_ONLY"
        and t1c013.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_013_ONLY"
        and t1c013.get("second_reviewer_state") == "PATRICK_K_SPOON_SR_EQUINESYNC_COO_ASSIGNED_SECOND_REVIEWER_ACCEPTED_T1C_013_ONLY_ON_2026_08_13"
        and t1c013.get("authority_effect") == expected_authority
        and t1c013.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c013, sort_keys=True),
    )

    ev = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")}
    t1c013_ev = ev.get("T1C-013", {})
    failures += add(
        checks,
        "t1c013_per_finding_final_closure_evidence_recorded",
        t1c013_ev.get("closure_assertion") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_013_ONLY"
        and t1c013_ev.get("validation_or_review_required") == "PATRICK_SECOND_REVIEWER_ACCEPTANCE_RECORDED_NO_FURTHER_T1C_013_REVIEW_REQUIRED_FOR_FINDING_ONLY_CLOSURE"
        and "NONE_FOR_T1C_013_FINDING_ONLY_CLOSURE" in t1c013_ev.get("remaining_open_item", ""),
        json.dumps(t1c013_ev, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    failures += add(
        checks,
        "t1c013_removed_from_blocked_register_after_finding_only_closure",
        not any("T1C-013" in " ".join(row.values()) for row in blocked),
        json.dumps([row for row in blocked if "T1C-013" in " ".join(row.values())], sort_keys=True),
    )

    record = package / "T1C-013_FINAL_CLOSURE_RECORD.md"
    text = record.read_text(encoding="utf-8") if record.exists() else ""
    required = ["FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_013_ONLY", "Patrick K. Spoon Sr.", "2026-08-13", expected_authority, "MERGE_NOT_AUTHORIZED"]
    failures += add(checks, "t1c013_final_closure_record_present", record.exists() and all(token in text for token in required), json.dumps([token for token in required if token not in text]))

    retained = {row["t1c_id"] for row in reg.values() if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    expected_still_open = {"T1C-003", "T1C-006", "T1C-020"}
    failures += add(checks, "remaining_required_items_retained_open_after_t1c013_closure", expected_still_open.issubset(retained) and "T1C-013" not in retained, f"required={sorted(expected_still_open)} retained={sorted(retained)}")

    forbidden = ["LIVE_PR_RELIANCE_AUTHORIZED", "REBASE_AUTHORIZED", "BRANCH_MUTATION_AUTHORIZED", "CI_RERUN_AUTHORIZED", "MERGE_AUTHORIZED", "IMPLEMENTATION_AUTHORIZED", "PRODUCTION_USE_AUTHORIZED", "CERTIFICATION_COMPLETE", "RISK_ACCEPTED", "PACKAGE_FINAL_CLOSURE_GRANTED"]
    combined = "\n".join([json.dumps(t1c013), json.dumps(t1c013_ev), text])
    found = [token for token in forbidden if token in combined]
    failures += add(checks, "no_t1c013_closure_authority_elevation", not found, json.dumps(found))

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {"status": status, "failures": failures, "checks": checks}
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
