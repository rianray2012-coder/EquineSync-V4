#!/usr/bin/env python3
import argparse, csv, json, shutil, subprocess, sys, tempfile
from pathlib import Path

def read_csv(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))

def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)

def collapse_lifecycle(root):
    p = root / "04_AUTHORITY_LIFECYCLE_REGISTER/LIFECYCLE_TRANSITION_MATRIX.csv"
    rows = read_csv(p)
    for row in rows:
        prefix = f"{row['permitted_starting_state']}_TO_{row['permitted_next_state']}_"
        row["reversal_rules"] = prefix + "REVERSAL_REQUIRES_EXPLICIT_RESCISSION_OR_REMEDIATION_EVIDENCE"
        row["reactivation_rules"] = prefix + "REACTIVATION_REQUIRES_AUTHORITY_AND_EVIDENCE"
    write_csv(p, rows)

def break_doc03_metrics(root):
    p = root / "03_IMPLEMENTATION_TRACEABILITY/COVERAGE_METRICS_BY_DOMAIN.csv"
    rows = read_csv(p)
    for row in rows:
        if row["domain"] == "OVERALL":
            row["total_source_text_candidates"] = "96"
            row["open_candidate_rows"] = "96"
    write_csv(p, rows)

def break_invalid_lifecycle_rule(rule_id):
    def mutate(root):
        p = root / "04_AUTHORITY_LIFECYCLE_REGISTER/AUTHORITY_LIFECYCLE_STATE_REGISTER.csv"
        rows = read_csv(p)
        row = rows[0]
        if rule_id == "T1R2-LIFE-RULE-01":
            row["activation_state"] = "ACTIVE"; row["adoption_state"] = "NOT_ADOPTED"
        elif rule_id == "T1R2-LIFE-RULE-02":
            row["adoption_state"] = "ADOPTED"; row["approval_evidence"] = ""
        elif rule_id == "T1R2-LIFE-RULE-03":
            row["accession_state"] = "ACCESSIONED"; row["accession_evidence"] = ""
        elif rule_id == "T1R2-LIFE-RULE-04":
            row["custody_state"] = "CUSTODY_COMPLETE"; row["accession_state"] = "NOT_ACCESSIONED"
        elif rule_id == "T1R2-LIFE-RULE-05":
            row["supersession_state"] = "SUPERSEDED_BY_TEST_FIXTURE"; row["successor_or_basis"] = ""
        elif rule_id == "T1R2-LIFE-RULE-06":
            row["document_lifecycle_state"] = "LOCKED"; row["lock_evidence"] = ""
        elif rule_id == "T1R2-LIFE-RULE-07":
            row["authority_state"] = "EFFECTIVE"; row["effective_date"] = ""
        elif rule_id == "T1R2-LIFE-RULE-08":
            row["implementation_authority"] = "AUTHORIZED"; row["authority_state"] = "DOCUMENTARY_CANDIDATE_ONLY"
        elif rule_id == "T1R2-LIFE-RULE-09":
            row["production_authority"] = "AUTHORIZED"; row["activation_state"] = "NOT_ACTIVE"
        elif rule_id == "T1R2-LIFE-RULE-10":
            row["suspension_state"] = "SUSPENDED"; row["activation_state"] = "ACTIVE"
        elif rule_id == "T1R2-LIFE-RULE-11":
            row["document_lifecycle_state"] = "HISTORICAL_RETAINED"; row["authority_state"] = "CONTROLLING"
        elif rule_id == "T1R2-LIFE-RULE-12":
            row["authority_state"] = "DOCUMENTARY_CANDIDATE_ONLY"; row["adoption_state"] = "ADOPTED"
        write_csv(p, rows)
    return mutate

def run_case(package, name, mutate, expected):
    with tempfile.TemporaryDirectory() as td:
        temp = Path(td) / package.name
        shutil.copytree(package, temp, ignore=shutil.ignore_patterns("*.zip", "__pycache__"))
        mutate(temp)
        validator = temp / "VALIDATION/validate_tier1_documents_03_10_v5.py"
        result = subprocess.run([sys.executable, str(validator), "--package-root", str(temp)], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return {"fixture": name, "expected_check": expected, "expected_failure_detected": result.returncode != 0 and expected in result.stdout}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = [
        run_case(package, "mechanically_uniquified_lifecycle_rules", collapse_lifecycle, "lifecycle_prefix_stripped_reversal_rules"),
        run_case(package, "doc03_coverage_reverts_to_96", break_doc03_metrics, "doc03_coverage_matches_non_rejected"),
    ]
    for i in range(1, 13):
        rule_id = f"T1R2-LIFE-RULE-{i:02d}"
        checks.append(run_case(package, f"invalid_lifecycle_rule_{rule_id}", break_invalid_lifecycle_rule(rule_id), f"invalid_lifecycle_rule_enforced:{rule_id}"))
    report = {"status": "PASS" if all(c["expected_failure_detected"] for c in checks) else "FAIL", "fixture_count": len(checks), "checks": checks}
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
