#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_T1C010_T1C019_ASSIGNED_SECOND_REVIEWER_CLOSED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    manifest = json.loads((package / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    failures += add(
        checks,
        "package_status_records_t1c010_closure_without_package_final_closure",
        manifest.get("package_status") == EXPECTED_STATUS,
        manifest.get("package_status", ""),
    )

    reg = {
        row["t1c_id"]: row
        for row in rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    }
    t1c010 = reg.get("T1C-010", {})
    failures += add(
        checks,
        "t1c010_final_closed_by_assigned_second_reviewer_only",
        t1c010.get("current_target_disposition") == "PATRICK_SECOND_REVIEWER_ACCEPTED_FINAL_CLOSURE_T1C_010_ONLY"
        and t1c010.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_010_ONLY"
        and t1c010.get("second_reviewer_state")
        == "PATRICK_K_SPOON_SR_EQUINESYNC_COO_ASSIGNED_SECOND_REVIEWER_ACCEPTED_T1C_010_ONLY_ON_2026_08_13"
        and t1c010.get("authority_effect")
        == "T1C_010_FINDING_FINAL_CLOSURE_ONLY_BY_ASSIGNED_SECOND_REVIEWER_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_RUNTIME_TEST_EXECUTION_DEPLOYMENT_PRODUCTION_MERGE_CERTIFICATION_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
        and t1c010.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c010, sort_keys=True),
    )

    ev = {
        row["t1c_id"]: row
        for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")
    }
    t1c010_ev = ev.get("T1C-010", {})
    failures += add(
        checks,
        "t1c010_per_finding_final_closure_evidence_recorded",
        t1c010_ev.get("closure_assertion")
        == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_010_ONLY"
        and t1c010_ev.get("validation_or_review_required")
        == "PATRICK_SECOND_REVIEWER_ACCEPTANCE_RECORDED_NO_FURTHER_T1C_010_REVIEW_REQUIRED_FOR_FINDING_ONLY_CLOSURE"
        and "NONE_FOR_T1C_010_FINDING_ONLY_CLOSURE" in t1c010_ev.get("remaining_open_item", ""),
        json.dumps(t1c010_ev, sort_keys=True),
    )

    closure_record = package / "T1C-010_FINAL_CLOSURE_RECORD.md"
    text = closure_record.read_text(encoding="utf-8") if closure_record.exists() else ""
    required = [
        "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_010_ONLY",
        "Patrick K. Spoon Sr.",
        "2026-08-13",
        "T1C_010_FINDING_FINAL_CLOSURE_ONLY_BY_ASSIGNED_SECOND_REVIEWER_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_RUNTIME_TEST_EXECUTION_DEPLOYMENT_PRODUCTION_MERGE_CERTIFICATION_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE",
        "MERGE_NOT_AUTHORIZED",
    ]
    failures += add(
        checks,
        "t1c010_final_closure_record_present",
        closure_record.exists() and all(token in text for token in required),
        json.dumps([token for token in required if token not in text]),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    failures += add(
        checks,
        "t1c010_removed_from_blocked_register_after_finding_only_closure",
        not any("T1C-010" in " ".join(row.values()) for row in blocked),
        json.dumps([row for row in blocked if "T1C-010" in " ".join(row.values())], sort_keys=True),
    )

    retained = {row["t1c_id"] for row in reg.values() if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    expected_still_open = {"T1C-003", "T1C-006", "T1C-013", "T1C-020"}
    failures += add(
        checks,
        "remaining_required_items_retained_open_after_t1c010_closure",
        expected_still_open.issubset(retained) and "T1C-010" not in retained,
        f"required={sorted(expected_still_open)} retained={sorted(retained)}",
    )

    forbidden = [
        "ADOPTION_READY",
        "ACTIVATION_AUTHORIZED",
        "IMPLEMENTATION_AUTHORIZED",
        "RUNTIME_EXECUTION_PERFORMED",
        "TEST_EXECUTION_PERFORMED",
        "DEPLOYMENT_COMPLETE",
        "PRODUCTION_USE_AUTHORIZED",
        "MERGE_AUTHORIZED",
        "CERTIFICATION_COMPLETE",
        "RISK_ACCEPTED",
        "PACKAGE_FINAL_CLOSURE_GRANTED",
        "BROADER_PACKAGE_FINAL_CLOSURE_GRANTED",
    ]
    combined = "\n".join([json.dumps(t1c010), json.dumps(t1c010_ev), text])
    found = [token for token in forbidden if token in combined]
    failures += add(checks, "no_t1c010_closure_authority_elevation", not found, json.dumps(found))

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {"status": status, "failures": failures, "checks": checks}
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
