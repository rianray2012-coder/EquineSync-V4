#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_T1C010_T1C013_T1C019_ASSIGNED_SECOND_REVIEWER_CLOSED_T1C020_FOUNDER_CLOSED"
EXPECTED_AUTHORITY = "T1C_020_FINDING_FINAL_CLOSURE_ONLY_BY_FOUNDER_FULL_PACKAGE_CI_LINUX_REPRODUCTION_EVIDENCE_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_CERTIFICATION_SECOND_REVIEWER_COMPLETION_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    manifest = json.loads((package / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    failures += add(checks, "package_status_records_t1c020_closure_without_package_final_closure", manifest.get("package_status") == EXPECTED_STATUS, manifest.get("package_status", ""))

    reg = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")}
    t1c020 = reg.get("T1C-020", {})
    failures += add(
        checks,
        "t1c020_final_closed_by_founder_full_ci_linux_reproduction_only",
        t1c020.get("current_target_disposition") == "FOUNDER_ACCEPTED_FULL_PACKAGE_CI_LINUX_REPRODUCTION_FINAL_CLOSURE_T1C_020_ONLY"
        and t1c020.get("closure_state") == "FINAL_CLOSED_BY_FOUNDER_AUTHORIZED_DISPOSITION_T1C_020_ONLY"
        and t1c020.get("second_reviewer_state") == "NOT_PERFORMED_NOT_REQUIRED_BY_FOUNDER_FOR_T1C_020_FINDING_ONLY_CI_LINUX_REPRODUCTION_CLOSURE_NO_BROADER_SECOND_REVIEWER_COMPLETION"
        and t1c020.get("authority_effect") == EXPECTED_AUTHORITY
        and t1c020.get("merge_effect") == "MERGE_NOT_AUTHORIZED"
        and "31690701485" in t1c020.get("current_target_evidence", "")
        and "261 package files" in t1c020.get("current_target_evidence", ""),
        json.dumps(t1c020, sort_keys=True),
    )

    ev = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")}
    t1c020_ev = ev.get("T1C-020", {})
    failures += add(
        checks,
        "t1c020_per_finding_closure_evidence_recorded",
        t1c020_ev.get("closure_assertion") == "FINAL_CLOSED_BY_FOUNDER_AUTHORIZED_DISPOSITION_T1C_020_ONLY"
        and t1c020_ev.get("validation_or_review_required") == "NO_FURTHER_T1C_020_REVIEW_REQUIRED_FOR_FINDING_ONLY_CLOSURE_BY_FOUNDER_ACCEPTED_FULL_PACKAGE_CI_LINUX_REPRODUCTION"
        and "NONE_FOR_T1C_020_FINDING_ONLY_CLOSURE" in t1c020_ev.get("remaining_open_item", "")
        and "31690701485" in t1c020_ev.get("evidence_locator", ""),
        json.dumps(t1c020_ev, sort_keys=True),
    )

    record = package / "T1C-020_FINAL_CLOSURE_RECORD.md"
    text = record.read_text(encoding="utf-8") if record.exists() else ""
    required = [
        "FINAL_CLOSED_BY_FOUNDER_AUTHORIZED_DISPOSITION_T1C_020_ONLY",
        "Founder accepted and authorized T1C-020 finding-only closure on 2026-08-13",
        "31690701485",
        "261",
        "failures: 0",
        "MERGE_NOT_AUTHORIZED",
    ]
    failures += add(checks, "t1c020_final_closure_record_present", record.exists() and all(token in text for token in required), json.dumps([token for token in required if token not in text]))

    retained = {row["t1c_id"] for row in reg.values() if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    expected_still_open = {"T1C-003", "T1C-006"}
    failures += add(checks, "remaining_required_items_retained_open_after_t1c020_closure", expected_still_open.issubset(retained) and "T1C-020" not in retained, f"required={sorted(expected_still_open)} retained={sorted(retained)}")

    forbidden = [
        "ADOPTION_READINESS_GRANTED",
        "ACTIVATION_GRANTED",
        "IMPLEMENTATION_GRANTED",
        "PRODUCTION_USE_GRANTED",
        "PROTECTED_MERGE_GRANTED",
        "CERTIFICATION_COMPLETION_GRANTED",
        "SECOND_REVIEWER_COMPLETION_GRANTED",
        "RISK_ACCEPTANCE_GRANTED",
        "PACKAGE_FINAL_CLOSURE_GRANTED",
    ]
    combined = "\n".join([json.dumps(t1c020), json.dumps(t1c020_ev), text, manifest.get("authority_boundary", "")])
    found = [token for token in forbidden if token in combined]
    failures += add(checks, "no_t1c020_closure_authority_elevation", not found, json.dumps(found))

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {"status": status, "failures": failures, "checks": checks}
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
