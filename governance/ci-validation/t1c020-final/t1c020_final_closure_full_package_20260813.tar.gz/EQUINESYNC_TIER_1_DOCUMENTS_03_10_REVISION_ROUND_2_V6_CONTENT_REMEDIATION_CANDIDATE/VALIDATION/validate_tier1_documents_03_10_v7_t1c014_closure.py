#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_T1C014_FOUNDER_CLOSED"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v5_json = package.parent / "v5_validation_for_v7_t1c014_closure.json"
    v5_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v5.py"
    v5 = subprocess.run(
        [sys.executable, str(v5_script), "--package-root", str(package), "--json-output", str(v5_json)],
        text=True,
        capture_output=True,
    )
    v5_report = json.loads(v5_json.read_text(encoding="utf-8"))
    failed_checks = [r["check"] for r in v5_report.get("results", []) if r.get("status") != "PASS"]
    failures += add(
        checks,
        "v5_only_expected_t1c014_open_retention_failure",
        v5.returncode == 1 and v5_report.get("failures") == 1 and failed_checks == ["required_t1c_items_retained_open"],
        f"v5_status={v5_report.get('status')} failures={v5_report.get('failures')} failed_checks={failed_checks}",
    )

    reg = rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    by_id = {row["t1c_id"]: row for row in reg}
    t1c014 = by_id.get("T1C-014", {})
    failures += add(
        checks,
        "t1c014_founder_authorized_final_closure",
        t1c014.get("current_target_disposition") == "FOUNDER_AUTHORIZED_FINAL_CLOSURE_AFTER_V6_CONTENT_REMEDIATION"
        and t1c014.get("closure_state") == "FINAL_CLOSED_BY_FOUNDER_AUTHORIZED_DISPOSITION"
        and t1c014.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c014, sort_keys=True),
    )
    failures += add(
        checks,
        "t1c014_closure_record_present",
        (package / "T1C-014_FINAL_CLOSURE_RECORD.md").is_file()
        and "FINAL_CLOSED_BY_FOUNDER_AUTHORIZED_DISPOSITION" in (package / "T1C-014_FINAL_CLOSURE_RECORD.md").read_text(encoding="utf-8"),
        "T1C-014 final closure record is present and names the closure state",
    )
    still_open = {"T1C-003", "T1C-006", "T1C-010", "T1C-013", "T1C-016", "T1C-019", "T1C-020"}
    retained = {row["t1c_id"] for row in reg if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    failures += add(
        checks,
        "other_required_retained_open_items_still_open",
        still_open.issubset(retained),
        f"required={sorted(still_open)} retained={sorted(retained)}",
    )
    failures += add(
        checks,
        "authority_boundary_preserved",
        AUTHORITY_BOUNDARY in (package / "T1C-014_FINAL_CLOSURE_RECORD.md").read_text(encoding="utf-8")
        or "does not authorize adoption, activation, implementation, production use, merge, certification completion, second-reviewer completion, risk acceptance" in (package / "T1C-014_FINAL_CLOSURE_RECORD.md").read_text(encoding="utf-8"),
        "T1C-014 closure is finding-only and preserves broader authority boundary",
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
