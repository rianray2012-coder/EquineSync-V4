#!/usr/bin/env python3
import argparse
import csv
import json
import re
import subprocess
import sys
from pathlib import Path

AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"
EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def trivial(field, definition):
    normalized_field = re.sub(r"[_\s]+", " ", field.strip().lower())
    normalized_definition = re.sub(r"[`_.\s]+", " ", definition.strip().lower()).strip()
    return normalized_definition in {normalized_field, f"the {normalized_field}", f"{normalized_field} field", ""}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []

    def add(name, ok, detail):
        checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
        return 0 if ok else 1

    failures = 0
    v5_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v5.py"
    v5 = subprocess.run([sys.executable, str(v5_script), "--package-root", str(package)], text=True, capture_output=True)
    failures += add("v5_structural_validator_zero_failures", v5.returncode == 0 and "STRUCTURAL_PASS_SUBSTANTIVE_CLOSURE_BLOCKED" in v5.stdout, "V5 structural validator preserves blocked-substantive distinction")

    trivial_rows = []
    generic_permitted = []
    for path in sorted((package / "DATA_DICTIONARIES").glob("*_DATA_DICTIONARY.csv")):
        for row in rows(path):
            if trivial(row["field_name"], row.get("definition", "")):
                trivial_rows.append(f"{path.name}:{row['field_name']}")
            if row.get("permitted_values", "").strip() == "controlled by validator or source register where applicable":
                generic_permitted.append(f"{path.name}:{row['field_name']}")
    failures += add("data_dictionary_trivial_definitions_zero", not trivial_rows, f"trivial_count={len(trivial_rows)}")
    failures += add("data_dictionary_generic_permitted_values_zero", not generic_permitted, f"generic_count={len(generic_permitted)}")

    schema_issues = []
    for path in sorted((package / "SCHEMAS").glob("*.schema.json")):
        data = json.loads(path.read_text())
        if data.get("additionalProperties") is not False:
            schema_issues.append(f"{path.name}:additionalProperties")
        for field, prop in data.get("properties", {}).items():
            lf = field.lower()
            narrative = any(token in lf for token in ["rationale", "reason", "analysis", "summary", "text", "criteria", "action"])
            controlled = any(token in lf for token in ["state", "status", "disposition", "severity", "authority", "permission", "boundary"])
            if controlled and not narrative and not any(k in prop for k in ["enum", "pattern"]):
                schema_issues.append(f"{path.name}:{field}:unconstrained_control_field")
    failures += add("schemas_safe_content_constraints_present", not schema_issues, f"schema_issue_count={len(schema_issues)}")

    evidence_issues = []
    generic_values = {"", "TBD", "TODO", "N/A", "NONE", "MISSING", "UNKNOWN"}
    for csv_path in package.rglob("*.csv"):
        if "DATA_DICTIONARIES" in csv_path.parts or "FIXTURES" in csv_path.parts:
            continue
        for i, row in enumerate(rows(csv_path), start=2):
            for field, value in row.items():
                if any(token in field.lower() for token in ["evidence", "locator", "artifact_path"]):
                    if (value or "").strip().upper() in generic_values:
                        evidence_issues.append(f"{csv_path.relative_to(package)}:{i}:{field}")
    failures += add("blank_or_generic_evidence_locators_absent", not evidence_issues, f"evidence_issue_count={len(evidence_issues)}")

    blocked = package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv"
    blocked_rows = rows(blocked) if blocked.exists() else []
    failures += add("blocked_sections_machine_readable", len(blocked_rows) >= 3 and all(r.get("retained_status") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN" for r in blocked_rows), f"blocked_rows={len(blocked_rows)}")

    unresolved_text = (package / "UNRESOLVED_ISSUE_REGISTER.csv").read_text(encoding="utf-8")
    failures += add("blocked_items_remain_unresolved", "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN" in unresolved_text, "blocked status retained in unresolved issue register")

    forbidden = {"ADOPTION_READY", "ACTIVATION_READY", "PRODUCTION_AUTHORIZED", "MERGE_AUTHORIZED", "CERTIFICATION_COMPLETE", "FOUNDER_APPROVED", "SECOND_REVIEWER_COMPLETE", "RISK_ACCEPTED"}
    claims = []
    authority_fields = ("status", "state", "authority", "permission", "certification", "founder", "reviewer", "risk", "closure", "adoption", "activation", "merge", "production")
    for csv_path in package.rglob("*.csv"):
        if "SOURCE_REVIEWS" in csv_path.parts or csv_path.name.startswith("SOURCE_AUTHENTICATION"):
            continue
        for i, row in enumerate(rows(csv_path), start=2):
            for field, value in row.items():
                if any(token in field.lower() for token in authority_fields) and (value or "").strip().upper() in forbidden:
                    claims.append(f"{csv_path.relative_to(package)}:{i}:{field}:{value}")
    for md_path in package.rglob("*.md"):
        if "SOURCE_REVIEWS" in md_path.parts:
            continue
        for i, line in enumerate(md_path.read_text(encoding="utf-8", errors="ignore").splitlines(), start=1):
            upper = line.strip().upper()
            if any(upper.endswith(token) or f": {token}" in upper for token in forbidden):
                claims.append(f"{md_path.relative_to(package)}:{i}")
    failures += add("no_forbidden_authority_elevation_claims", not claims, "forbidden_claims=" + ",".join(claims[:20]))

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "package_status": EXPECTED_STATUS,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
