#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_CLOSURE_AWARE_V9"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def run_json(script, package, output_name):
    output = package.parent / output_name
    result = subprocess.run(
        [sys.executable, str(script), "--package-root", str(package), "--json-output", str(output)],
        text=True,
        capture_output=True,
    )
    return result, json.loads(output.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v5_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v5.py"
    v5, v5_report = run_json(v5_script, package, "v5_validation_for_v9_closure_aware.json")
    v5_failed = [r["check"] for r in v5_report.get("results", []) if r.get("status") != "PASS"]
    failures += add(
        checks,
        "v5_only_stale_retained_open_aggregate_failure",
        v5.returncode == 1 and v5_report.get("failures") == 1 and v5_failed == ["required_t1c_items_retained_open"],
        f"v5_status={v5_report.get('status')} failures={v5_report.get('failures')} failed_checks={v5_failed}",
    )

    v8_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v8_t1c011_closure.py"
    v8, v8_report = run_json(v8_script, package, "v8_validation_for_v9_closure_aware.json")
    failures += add(
        checks,
        "v8_t1c014_t1c011_closure_validator_passes",
        v8.returncode == 0 and v8_report.get("failures") == 0,
        f"v8_status={v8_report.get('status')} failures={v8_report.get('failures')}",
    )

    reg = rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    by_id = {row["t1c_id"]: row for row in reg}

    still_open = {"T1C-003", "T1C-006", "T1C-010", "T1C-013", "T1C-016", "T1C-019", "T1C-020"}
    retained = {row["t1c_id"] for row in reg if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    failures += add(
        checks,
        "closure_aware_required_items_retained_open",
        still_open.issubset(retained),
        f"required={sorted(still_open)} retained={sorted(retained)}",
    )

    t1c014 = by_id.get("T1C-014", {})
    failures += add(
        checks,
        "t1c014_authorized_finding_only_closed_not_retained_open",
        t1c014.get("closure_state") == "FINAL_CLOSED_BY_FOUNDER_AUTHORIZED_DISPOSITION"
        and t1c014.get("authority_effect") == "T1C_014_FINDING_FINAL_CLOSURE_ONLY_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_CERTIFICATION_SECOND_REVIEWER_OR_RISK_ACCEPTANCE"
        and t1c014.get("merge_effect") == "MERGE_NOT_AUTHORIZED"
        and "OPEN" not in t1c014.get("closure_state", ""),
        json.dumps(t1c014, sort_keys=True),
    )

    t1c011 = by_id.get("T1C-011", {})
    failures += add(
        checks,
        "t1c011_authorized_finding_only_closed_not_retained_open",
        t1c011.get("closure_state") == "FINAL_CLOSED_BY_AUTHORIZED_DISPOSITION_T1C_011_ONLY"
        and t1c011.get("authority_effect") == "T1C_011_FINDING_FINAL_CLOSURE_ONLY_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_CERTIFICATION_SECOND_REVIEWER_OR_RISK_ACCEPTANCE"
        and t1c011.get("merge_effect") == "MERGE_NOT_AUTHORIZED"
        and "OPEN" not in t1c011.get("closure_state", ""),
        json.dumps(t1c011, sort_keys=True),
    )

    t1c006 = by_id.get("T1C-006", {})
    failures += add(
        checks,
        "t1c006_retained_open_after_rejected_fragment_classification",
        t1c006.get("closure_state") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and t1c006.get("current_target_disposition") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_AFTER_FOUNDER_AUTHORIZED_REJECTED_FRAGMENT_SUBPOPULATION_CLASSIFICATION"
        and t1c006.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c006, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    failures += add(
        checks,
        "t1c006_blocked_register_row_present",
        any(
            row.get("retained_status") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
            and "T1C-006" in row.get("blocked_item", "")
            and row.get("priority_classification") == "blocking"
            for row in blocked
        ),
        f"blocked_rows={len(blocked)}",
    )

    unresolved = rows(package / "UNRESOLVED_ISSUE_REGISTER.csv")
    failures += add(
        checks,
        "t1c006_unresolved_issue_row_present",
        any(
            row.get("issue_id") == "T1C-006"
            and row.get("classification") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
            and row.get("blocking") == "YES_BLOCKING_FOR_T1C_006_FINAL_CLOSURE"
            for row in unresolved
        ),
        f"unresolved_rows={len(unresolved)}",
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
