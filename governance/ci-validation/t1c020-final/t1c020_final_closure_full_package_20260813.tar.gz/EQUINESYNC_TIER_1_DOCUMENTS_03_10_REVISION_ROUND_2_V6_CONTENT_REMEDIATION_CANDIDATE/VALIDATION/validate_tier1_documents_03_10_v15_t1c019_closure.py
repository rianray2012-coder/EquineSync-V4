#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_T1C019_ASSIGNED_SECOND_REVIEWER_CLOSED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    reg = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")}
    t1c019 = reg.get("T1C-019", {})
    failures += add(
        checks,
        "t1c019_final_closed_by_assigned_second_reviewer_only",
        t1c019.get("current_target_disposition") == "PATRICK_SECOND_REVIEWER_ACCEPTED_FINAL_CLOSURE_T1C_019_ONLY"
        and t1c019.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_019_ONLY"
        and t1c019.get("second_reviewer_state") == "PATRICK_K_SPOON_SR_EQUINESYNC_COO_ASSIGNED_SECOND_REVIEWER_ACCEPTED_T1C_019_ONLY_ON_2026_08_12"
        and t1c019.get("authority_effect") == "T1C_019_FINDING_FINAL_CLOSURE_ONLY_BY_ASSIGNED_SECOND_REVIEWER_NO_PACKAGE_WIDE_SECOND_REVIEWER_COMPLETION_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_CERTIFICATION_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
        and t1c019.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c019, sort_keys=True),
    )

    ev = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")}
    t1c019_ev = ev.get("T1C-019", {})
    failures += add(
        checks,
        "t1c019_per_finding_closure_evidence_final",
        t1c019_ev.get("closure_assertion") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_019_ONLY"
        and "NONE_FOR_T1C_019_FINDING_ONLY_CLOSURE" in t1c019_ev.get("remaining_open_item", "")
        and "T1C-019_FINAL_CLOSURE_RECORD.md" in t1c019_ev.get("evidence_locator", ""),
        json.dumps(t1c019_ev, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    blocked_text = [" ".join(row.values()) for row in blocked]
    failures += add(
        checks,
        "t1c019_removed_from_blocked_retained_open_register",
        not any("T1C-019" in text for text in blocked_text),
        f"blocked_rows={len(blocked)}",
    )

    record = package / "T1C-019_FINAL_CLOSURE_RECORD.md"
    text = record.read_text(encoding="utf-8") if record.exists() else ""
    required = [
        "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_019_ONLY",
        "Patrick K. Spoon Sr.",
        "finding-only final closure",
        "does not authorize",
        "package-wide second-reviewer completion",
    ]
    failures += add(
        checks,
        "t1c019_final_closure_record_present",
        all(token in text for token in required),
        json.dumps([token for token in required if token not in text]),
    )

    retained = {row["t1c_id"] for row in reg.values() if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    expected_still_open = {"T1C-003", "T1C-006", "T1C-010", "T1C-013", "T1C-020"}
    failures += add(
        checks,
        "remaining_required_items_retained_open_after_t1c019_closure",
        expected_still_open.issubset(retained) and "T1C-019" not in retained,
        f"required={sorted(expected_still_open)} retained={sorted(retained)}",
    )

    t1c016 = reg.get("T1C-016", {})
    failures += add(
        checks,
        "t1c016_still_final_closed_only",
        t1c016.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_016_ONLY"
        and t1c016.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c016, sort_keys=True),
    )

    forbidden = [
        "PACKAGE_FINAL_CLOSURE_GRANTED",
        "PRODUCTION_USE_AUTHORIZED_BY_T1C_019",
        "MERGE_AUTHORIZED_BY_T1C_019",
        "RISK_ACCEPTED_BY_T1C_019",
        "CERTIFICATION_COMPLETE_BY_T1C_019",
        "PACKAGE_WIDE_SECOND_REVIEWER_COMPLETION_GRANTED",
    ]
    combined = "\n".join([json.dumps(t1c019), json.dumps(t1c019_ev), text])
    failures += add(
        checks,
        "no_t1c019_authority_elevation",
        not any(token in combined for token in forbidden),
        json.dumps([token for token in forbidden if token in combined]),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {"status": status, "failures": failures, "checks": checks}
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
