#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_FOUNDER_ACCEPTED_DOCUMENTARY_PACKAGE_T1C019_ASSIGNED_SECOND_REVIEWER_CLOSED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    outputs = package.parent
    checks = []
    failures = 0

    reg = {
        row["t1c_id"]: row
        for row in rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    }
    t1c010 = reg.get("T1C-010", {})
    failures += add(
        checks,
        "t1c010_retained_open_in_consolidated_register",
        t1c010.get("current_target_disposition")
        == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_PENDING_OUTSIDE_REVIEWER_ACCEPTANCE"
        and t1c010.get("closure_state") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and t1c010.get("source_review_ids") == "CURSOR-VR3-007"
        and t1c010.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c010, sort_keys=True),
    )

    expected_authority = (
        "T1C_010_RETAINED_OPEN_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_RUNTIME_TEST_EXECUTION_"
        "DEPLOYMENT_PRODUCTION_MERGE_CERTIFICATION_SECOND_REVIEWER_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
    )
    failures += add(
        checks,
        "t1c010_no_authority_elevation_in_consolidated_register",
        t1c010.get("authority_effect") == expected_authority
        and "final closure" not in t1c010.get("current_target_evidence", "").lower().replace("no broader package final closure", ""),
        t1c010.get("authority_effect", ""),
    )

    ev = {
        row["t1c_id"]: row
        for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")
    }
    t1c010_ev = ev.get("T1C-010", {})
    failures += add(
        checks,
        "t1c010_per_finding_register_not_closed",
        t1c010_ev.get("closure_assertion") == "NOT_CLOSED_CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and "OUTSIDE_REVIEWER_ACCEPTANCE_REQUIRED_FOR_T1C_010_FINDING_ONLY_CLOSURE"
        in t1c010_ev.get("validation_or_review_required", "")
        and "SEPARATE_AUTHORITY_REQUIRED_FOR_ANY_IMPLEMENTATION_DEPLOYMENT_PRODUCTION_RUNTIME_TEST_MERGE_CERTIFICATION_OR_RISK_CLAIM"
        in t1c010_ev.get("validation_or_review_required", ""),
        json.dumps(t1c010_ev, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    t1c010_blocked = [row for row in blocked if "T1C-010" in " ".join(row.values())]
    failures += add(
        checks,
        "t1c010_specific_blocked_retained_open_row_present",
        len(t1c010_blocked) == 1
        and t1c010_blocked[0].get("retained_status") == "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN"
        and t1c010_blocked[0].get("priority_classification") == "high-priority",
        json.dumps(t1c010_blocked, sort_keys=True),
    )

    required_artifacts = [
        "T1C-010_SCOPE_CONFIRMATION.md",
        "T1C-010_TASK_ITEM_2_EVIDENCE_STATE_SURFACE_INVENTORY.md",
        "T1C-010_TASK_ITEM_3_AUTHORITY_BOUNDARY_LANGUAGE_REVIEW.md",
        "T1C-010_TASK_ITEM_4_REGISTER_AND_DICTIONARY_REMEDIATION.md",
        "T1C-010_TASK_ITEM_5_BLOCKED_RETAINED_OPEN_REGISTER_ALIGNMENT.md",
    ]
    missing = [name for name in required_artifacts if not (outputs / name).exists()]
    failures += add(
        checks,
        "t1c010_task_1_5_artifacts_present",
        not missing,
        json.dumps(missing),
    )

    metrics = rows(package / "03_IMPLEMENTATION_TRACEABILITY" / "COVERAGE_METRICS_BY_DOMAIN.csv")
    metric_failures = []
    for row in metrics:
        for field in [
            "accepted_normative_requirements",
            "implementations_verified",
            "assertion_level_tests_verified",
            "tests_executed",
            "tests_passed",
            "runtime_evidence_present",
            "production_evidence_present",
        ]:
            if row.get(field) not in {"0", "0.0"}:
                metric_failures.append({"domain": row.get("domain"), "field": field, "value": row.get(field)})
    failures += add(
        checks,
        "document03_metrics_do_not_claim_runtime_test_or_production_evidence",
        not metric_failures,
        json.dumps(metric_failures, sort_keys=True),
    )

    founder = rows(package / "05_FOUNDER_DECISION_REGISTER" / "FOUNDER_DECISION_DISPOSITION_REGISTER.csv")
    founder_violations = []
    for row in founder:
        joined = " ".join(row.values())
        if row.get("authority_granted") != "NONE_BY_THIS_PACKAGE":
            founder_violations.append({"decision_id": row.get("decision_id"), "authority_granted": row.get("authority_granted")})
        for token in ["IMPLEMENTATION_NOT_AUTHORIZED", "PRODUCTION_USE_NOT_AUTHORIZED", "MERGE_NOT_AUTHORIZED"]:
            if token not in joined:
                founder_violations.append({"decision_id": row.get("decision_id"), "missing": token})
    failures += add(
        checks,
        "founder_decision_surface_preserves_no_operational_authority",
        not founder_violations,
        json.dumps(founder_violations, sort_keys=True),
    )

    forbidden_tokens = [
        "ADOPTION_READY",
        "ADOPTION_READINESS",
        "ACTIVATION_AUTHORIZED",
        "IMPLEMENTATION_AUTHORIZED",
        "RUNTIME_EXECUTION_PERFORMED",
        "TEST_EXECUTION_PERFORMED",
        "DEPLOYMENT_COMPLETE",
        "PRODUCTION_USE_AUTHORIZED",
        "MERGE_AUTHORIZED",
        "CERTIFICATION_COMPLETE",
        "RISK_ACCEPTED",
        "SECOND_REVIEWER_COMPLETION",
        "PACKAGE_FINAL_CLOSURE_GRANTED",
        "FINAL_CLOSED_BY_AUTHORIZED_DISPOSITION_T1C_010_ONLY",
    ]
    combined = "\n".join(
        [
            json.dumps(t1c010, sort_keys=True),
            json.dumps(t1c010_ev, sort_keys=True),
            json.dumps(t1c010_blocked, sort_keys=True),
        ]
    )
    found_forbidden = [token for token in forbidden_tokens if token in combined]
    failures += add(
        checks,
        "no_t1c010_forbidden_authority_tokens",
        not found_forbidden,
        json.dumps(found_forbidden),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {"status": status, "failures": failures, "checks": checks}
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
