#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_T1C014_AND_T1C011_FOUNDER_REVIEWER_CLOSED"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v7_json = package.parent / "v7_validation_for_v8_t1c011_closure.json"
    v7_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v7_t1c014_closure.py"
    v7 = subprocess.run(
        [sys.executable, str(v7_script), "--package-root", str(package), "--json-output", str(v7_json)],
        text=True,
        capture_output=True,
    )
    v7_report = json.loads(v7_json.read_text(encoding="utf-8"))
    failures += add(
        checks,
        "v7_t1c014_closure_validator_passes",
        v7.returncode == 0 and v7_report.get("failures") == 0,
        f"v7_status={v7_report.get('status')} failures={v7_report.get('failures')}",
    )

    reg = rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    by_id = {row["t1c_id"]: row for row in reg}
    t1c011 = by_id.get("T1C-011", {})
    failures += add(
        checks,
        "t1c011_authorized_finding_only_final_closure",
        t1c011.get("current_target_disposition") == "FOUNDER_REVIEWER_AUTHORIZED_FINAL_CLOSURE_AFTER_T1C011_LIFECYCLE_REMEDIATION"
        and t1c011.get("closure_state") == "FINAL_CLOSED_BY_AUTHORIZED_DISPOSITION_T1C_011_ONLY"
        and t1c011.get("authority_effect") == "T1C_011_FINDING_FINAL_CLOSURE_ONLY_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_CERTIFICATION_SECOND_REVIEWER_OR_RISK_ACCEPTANCE"
        and t1c011.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c011, sort_keys=True),
    )

    closure = package / "T1C-011_FINAL_CLOSURE_RECORD.md"
    closure_text = closure.read_text(encoding="utf-8") if closure.is_file() else ""
    failures += add(
        checks,
        "t1c011_closure_record_present",
        closure.is_file()
        and "FINAL_CLOSED_BY_AUTHORIZED_DISPOSITION_T1C_011_ONLY" in closure_text
        and "candidate supersession is accepted as supersession metadata" in closure_text,
        "T1C-011 final closure record is present and records candidate-supersession acceptance",
    )

    evidence = rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")
    ev_by_id = {row["t1c_id"]: row for row in evidence}
    failures += add(
        checks,
        "t1c011_per_finding_evidence_updated",
        ev_by_id.get("T1C-011", {}).get("closure_assertion") == "FINAL_CLOSED_BY_AUTHORIZED_DISPOSITION_T1C_011_ONLY",
        json.dumps(ev_by_id.get("T1C-011", {}), sort_keys=True),
    )

    residual = rows(package / "OUTSIDE_REVIEW" / "RESIDUAL_NONBLOCKING_AND_NEW_FINDING_REGISTER_V5.csv")
    res_by_id = {row["item_id"]: row for row in residual}
    failures += add(
        checks,
        "v4_01_lifecycle_residual_closed_for_t1c011",
        res_by_id.get("V4-01", {}).get("state") == "FINAL_CLOSED_BY_AUTHORIZED_DISPOSITION_T1C_011_ONLY",
        json.dumps(res_by_id.get("V4-01", {}), sort_keys=True),
    )

    still_open = {"T1C-003", "T1C-006", "T1C-010", "T1C-013", "T1C-016", "T1C-019", "T1C-020"}
    retained = {row["t1c_id"] for row in reg if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    failures += add(
        checks,
        "other_required_retained_open_items_still_open_after_t1c011",
        still_open.issubset(retained) and "T1C-011" not in retained,
        f"required={sorted(still_open)} retained={sorted(retained)}",
    )

    failures += add(
        checks,
        "authority_boundary_preserved_for_t1c011",
        "does not authorize adoption, activation, implementation, production use, merge, certification completion, second-reviewer completion, risk acceptance, or broader package final closure" in closure_text,
        "T1C-011 closure is finding-only and preserves broader authority boundary",
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
