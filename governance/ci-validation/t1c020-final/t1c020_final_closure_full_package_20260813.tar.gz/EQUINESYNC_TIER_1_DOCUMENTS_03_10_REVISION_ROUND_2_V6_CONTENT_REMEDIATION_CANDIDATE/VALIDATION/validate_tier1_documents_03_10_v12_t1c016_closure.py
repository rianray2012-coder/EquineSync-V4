#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

EXPECTED_STATUS = "STRUCTURAL_PASS_CONTENT_REMEDIATION_PARTIAL_SUBSTANTIVE_CLOSURE_BLOCKED_T1C016_ASSIGNED_SECOND_REVIEWER_CLOSED"
AUTHORITY_BOUNDARY = "NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED"

PRINCIPAL_DOCS = [
    "03_IMPLEMENTATION_TRACEABILITY/EQUINESYNC_MASTER_REQUIREMENT_TO_IMPLEMENTATION_TEST_EVIDENCE_TRACEABILITY_FRAMEWORK_REVISION_ROUND_2_V1.md",
    "04_AUTHORITY_LIFECYCLE_REGISTER/EQUINESYNC_AUTHORITY_LIFECYCLE_STATE_AND_TRANSITION_REGISTER_REVISION_ROUND_2_V1.md",
    "05_FOUNDER_DECISION_REGISTER/EQUINESYNC_FOUNDER_DECISION_SCOPE_AUTHORITY_AND_DISPOSITION_REGISTER_REVISION_ROUND_2_V1.md",
    "06_FINDINGS_RISKS_EXCEPTIONS_WAIVERS/EQUINESYNC_FINDINGS_RISKS_EXCEPTIONS_WAIVERS_AND_CLOSURE_CONTROL_REGISTER_REVISION_ROUND_2_V1.md",
    "07_OWNERSHIP_STEWARDSHIP_REVIEW/EQUINESYNC_GOVERNANCE_OWNERSHIP_ACCOUNTABILITY_AND_REVIEW_CALENDAR_REVISION_ROUND_2_V1.md",
    "08_SOURCE_RECONCILIATION/EQUINESYNC_SOURCE_PROVENANCE_AUTHORITY_AND_SUPERSESSION_RECONCILIATION_REVISION_ROUND_2_V1.md",
    "09_WORKSTREAM_PR_BRANCH_DISPOSITION/EQUINESYNC_OPEN_WORKSTREAM_PR_BRANCH_AND_EVIDENCE_DISPOSITION_REGISTER_REVISION_ROUND_2_V1.md",
    "10_CLOSING_AUDIT_PROTOCOL/EQUINESYNC_GOVERNANCE_CLOSING_AUDIT_PROTOCOL_AND_BOUNDED_CERTIFICATION_PACKAGE_REVISION_ROUND_2_V1.md",
]

REQUIRED_SECTIONS = [
    "## Definitions",
    "## Edge Cases",
    "## Dependencies",
]


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def add(checks, name, ok, detail):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    return 0 if ok else 1


def run_json(script, package, output_name):
    output = package.parent / output_name
    result = subprocess.run(
        [sys.executable, str(script), "--package-root", str(package), "--json-output", str(output)],
        text=True,
        capture_output=True,
    )
    return result, json.loads(output.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional_package_root", nargs="?")
    parser.add_argument("--package-root")
    parser.add_argument("--json-output")
    args = parser.parse_args()
    package = Path(args.package_root or args.positional_package_root or ".").resolve()
    checks = []
    failures = 0

    v9_script = package / "VALIDATION" / "validate_tier1_documents_03_10_v9_closure_aware.py"
    v9, v9_report = run_json(v9_script, package, "v9_validation_for_v12_t1c016_closure.json")
    v9_failed = [r["check"] for r in v9_report.get("checks", []) if r.get("status") != "PASS"]
    failures += add(
        checks,
        "v9_only_stale_t1c016_retained_open_expectation_failure",
        v9.returncode == 1
        and v9_report.get("failures") == 2
        and v9_failed == [
            "v8_t1c014_t1c011_closure_validator_passes",
            "closure_aware_required_items_retained_open",
        ],
        f"v9_status={v9_report.get('status')} failures={v9_report.get('failures')} failed_checks={v9_failed}",
    )

    reg = rows(package / "OUTSIDE_REVIEW" / "T1C_CONSOLIDATED_FINDINGS_DISPOSITION_REGISTER.csv")
    by_id = {row["t1c_id"]: row for row in reg}
    t1c016 = by_id.get("T1C-016", {})
    failures += add(
        checks,
        "t1c016_final_closed_by_assigned_second_reviewer_only",
        t1c016.get("closure_state") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_016_ONLY"
        and t1c016.get("current_target_disposition") == "PATRICK_SECOND_REVIEWER_ACCEPTED_FINAL_CLOSURE_T1C_016_ONLY"
        and t1c016.get("second_reviewer_state") == "PATRICK_K_SPOON_SR_EQUINESYNC_COO_ASSIGNED_SECOND_REVIEWER_ACCEPTED_T1C_016_ONLY_ON_2026_08_12"
        and t1c016.get("authority_effect") == "T1C_016_FINDING_FINAL_CLOSURE_ONLY_BY_ASSIGNED_SECOND_REVIEWER_NO_ADOPTION_ACTIVATION_IMPLEMENTATION_PRODUCTION_MERGE_CERTIFICATION_RISK_ACCEPTANCE_OR_PACKAGE_FINAL_CLOSURE"
        and t1c016.get("merge_effect") == "MERGE_NOT_AUTHORIZED",
        json.dumps(t1c016, sort_keys=True),
    )

    ev = {row["t1c_id"]: row for row in rows(package / "OUTSIDE_REVIEW" / "PER_FINDING_CLOSURE_EVIDENCE_REGISTER.csv")}
    t1c016_ev = ev.get("T1C-016", {})
    failures += add(
        checks,
        "t1c016_per_finding_closure_evidence_final",
        t1c016_ev.get("closure_assertion") == "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_016_ONLY"
        and "NONE_FOR_T1C_016_FINDING_ONLY_CLOSURE" in t1c016_ev.get("remaining_open_item", ""),
        json.dumps(t1c016_ev, sort_keys=True),
    )

    blocked = rows(package / "CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv")
    failures += add(
        checks,
        "t1c016_removed_from_blocked_retained_open_register",
        not any("T1C-016" in " ".join(row.values()) for row in blocked),
        f"blocked_rows={len(blocked)}",
    )

    retained = {row["t1c_id"] for row in reg if "OPEN" in row.get("closure_state", "") or "RETAINED" in row.get("closure_state", "")}
    still_open = {"T1C-003", "T1C-006", "T1C-010", "T1C-013", "T1C-019", "T1C-020"}
    failures += add(
        checks,
        "remaining_required_items_retained_open_after_t1c016_closure",
        still_open.issubset(retained) and "T1C-016" not in retained,
        f"required={sorted(still_open)} retained={sorted(retained)}",
    )

    closure_record = package.parent / "T1C-016_FINAL_CLOSURE_RECORD.md"
    closure_text = closure_record.read_text(encoding="utf-8") if closure_record.exists() else ""
    failures += add(
        checks,
        "t1c016_final_closure_record_present",
        "FINAL_CLOSED_BY_ASSIGNED_SECOND_REVIEWER_AUTHORIZED_DISPOSITION_T1C_016_ONLY" in closure_text
        and "Patrick K. Spoon Sr." in closure_text
        and "This closure does not authorize" in closure_text,
        str(closure_record),
    )

    missing_doc_checks = []
    for rel in PRINCIPAL_DOCS:
        text = (package / rel).read_text(encoding="utf-8")
        if AUTHORITY_BOUNDARY not in text:
            missing_doc_checks.append(f"{rel}:authority_boundary")
        for section in REQUIRED_SECTIONS:
            if section not in text:
                missing_doc_checks.append(f"{rel}:{section}")
        if "Acceptance Criteria" not in text:
            missing_doc_checks.append(f"{rel}:Acceptance Criteria")
    failures += add(
        checks,
        "principal_docs_depth_sections_and_boundary_present",
        not missing_doc_checks,
        "missing=" + json.dumps(missing_doc_checks),
    )

    status = "FAIL" if failures else EXPECTED_STATUS
    report = {
        "status": status,
        "failures": failures,
        "authority_boundary": AUTHORITY_BOUNDARY,
        "checks": checks,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.json_output:
        Path(args.json_output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
