# Document 04 - Authority Lifecycle State And Transition Register

Readiness determination: `REVISION_ROUND_2_REMEDIATION_IN_PROGRESS_CONTENT_REVISION_REQUIRED`.

Authority boundary: `NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED`.

The lifecycle model now covers all declared lifecycle states, including `DRAFT_UNMERGED`, `BLOCKED_EVIDENCE_REQUIRED`, `REJECTED`, and `REMEDIATION_REQUIRED`. `LIFECYCLE_TRANSITION_MATRIX.csv` is a 13-state transition matrix. Each permitted transition has transition-specific authority and evidence.

`INVALID_STATE_RULES.csv` includes `implementation_status` and `failure_capable` fields. Every rule marked `ENFORCED_BY_VALIDATOR` is implemented in the package validator. A rule must not be described as enforced unless the validator can fail on that condition.

## Definitions

A lifecycle state is a documentary status value recorded in `AUTHORITY_LIFECYCLE_STATE_REGISTER.csv`. A permitted transition is a state movement listed in `LIFECYCLE_TRANSITION_MATRIX.csv` with its required authority and evidence. An invalid state rule is a prohibited combination or misuse pattern recorded in `INVALID_STATE_RULES.csv`. `failure_capable=YES` means the package validator can fail when the prohibited condition is introduced.

## Acceptance Criteria For This Register

The lifecycle surface is adequate for documentary review only if the state vocabulary, transition matrix, invalid-rule table, and validator behavior are mutually consistent. A transition cannot be treated as allowed merely because two states exist. It must appear in the transition matrix and carry evidence and authority requirements. A rule cannot be treated as enforced unless a validator can detect violation.

## Register-Backed Example

The matrix and invalid-rule table should be read together. If a row is `BLOCKED_EVIDENCE_REQUIRED`, later movement must preserve the required evidence condition rather than silently advancing to an active, implemented, or closed state. This example explains the register method only; it does not adopt the lifecycle vocabulary for production or implementation.

## Edge Cases

Candidate supersession, rejected rows, remediation-required rows, and blocked-evidence rows are not interchangeable. A state label that mentions completion, remediation, or rejection does not itself create Founder approval, certification, merge authority, implementation authority, or closure. When state vocabulary conflicts with missing evidence, the missing evidence controls and the item remains open.

## Dependencies

This document depends on `AUTHORITY_LIFECYCLE_MODEL.json`, `AUTHORITY_LIFECYCLE_STATE_REGISTER.csv`, `LIFECYCLE_TRANSITION_MATRIX.csv`, `LIFECYCLE_RULE_CLASS_TABLE.csv`, and `INVALID_STATE_RULES.csv`. Any future adoption of the vocabulary as controlling authority requires express Founder action outside this document.

## V4 Purpose Scope Method And Limitations

Purpose: provide a reviewer-readable control surface for authority lifecycle without creating adoption, activation, implementation, production, merge, certification, waiver, risk-acceptance, final-closure, or Founder-approval authority.

Scope: limited to the V4 bounded rereview package, the registers in this directory, authenticated source-review inputs, and the PR #90 documentary custody context.

Method: thirteen-state vocabulary and permitted/prohibited transition reading. Reviewers should read register rows by row ID, source locator, evidence hash or byte count where present, status vocabulary, and retained-open fields. Blank, generic, or repeated analytical text is not closure evidence.

Limitations: this document is not a runtime assessment, legal opinion, production deployment record, certification report, or Founder decision. Open T1C rows remain open until independently adjudicated.

Evidence boundary: every conclusion must link to a package file, register row, source-review finding ID, validation report, or detached archive checksum. Absence of evidence must be recorded as open rather than inferred as remediated.
