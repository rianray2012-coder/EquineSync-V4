# Document 05 - Founder Decision Scope Authority And Disposition

Readiness determination: `REVISION_ROUND_2_REMEDIATION_IN_PROGRESS_CONTENT_REVISION_REQUIRED`.

Authority boundary: `NOT_ADOPTED; NOT_ACTIVE; IMPLEMENTATION_NOT_AUTHORIZED; PRODUCTION_USE_NOT_AUTHORIZED; MERGE_NOT_AUTHORIZED; CERTIFICATION_NOT_COMPLETE; FOUNDER_REVIEW_REQUIRED; UNRESOLVED_ITEMS_REMAIN_OPEN_AS_IDENTIFIED`.

All decision rows are decision frames only. `selected_disposition` is `NO_DISPOSITION_SELECTED` for every row, and `authority_granted` is `NONE_BY_THIS_PACKAGE`. Question text is byte-identical between the decision register, Founder packet CSV, and Founder packet Markdown.

## Definitions

A decision frame is a question and consequence structure prepared for Founder review without recording the answer. `selected_disposition=NO_DISPOSITION_SELECTED` means the package has not recorded approval, rejection, deferral, remediation direction, risk acceptance, waiver approval, or closure. `authority_granted=NONE_BY_THIS_PACKAGE` means the row does not create adoption, activation, implementation, production, merge, certification, or final-closure authority.

## Acceptance Criteria For This Register

A decision row is bounded only when the question, options, consequences, retained findings, authority exclusions, and no-effect fields remain consistent across the decision register, Founder packet CSV, and Founder packet Markdown. A decision row is not adequate if approval wording could be read as accepting residual risk, excluding findings, appointing reviewers, authorizing merge, authorizing production use, or closing unresolved items by silence.

## Register-Backed Example

`FD-T1R2-004` is the residual-risk decision frame. The package records no selected disposition and no accepted risk for that row. Founder approval of T1C-003 retained-open handling preserves the block; it does not accept residual risk or exclude any external findings unless future Founder text expressly identifies the rows and grants that authority.

## Edge Cases

Approval of a retained-open treatment is not the same as approval of risk acceptance. A malformed or incomplete decision population must not be cured by a broad approval word. If external findings, crosswalk rows, or Document 06 rows are incomplete, the decision remains bounded and open until the population and authority are expressly resolved.

## Dependencies

This document depends on `FOUNDER_DECISION_DISPOSITION_REGISTER.csv`, `FOUNDER_DECISION_DISPOSITION_REGISTER.json`, root `FOUNDER_DECISION_PACKET.csv`, root `FOUNDER_DECISION_PACKET.md`, `UNRESOLVED_ISSUE_REGISTER.csv`, and `CONTENT_REMEDIATION_BLOCKED_RETAINED_OPEN_REGISTER.csv`.

## V4 Purpose Scope Method And Limitations

Purpose: provide a reviewer-readable control surface for founder decision without creating adoption, activation, implementation, production, merge, certification, waiver, risk-acceptance, final-closure, or Founder-approval authority.

Scope: limited to the V4 bounded rereview package, the registers in this directory, authenticated source-review inputs, and the PR #90 documentary custody context.

Method: decision frames, consequences, and no-preselection posture. Reviewers should read register rows by row ID, source locator, evidence hash or byte count where present, status vocabulary, and retained-open fields. Blank, generic, or repeated analytical text is not closure evidence.

Limitations: this document is not a runtime assessment, legal opinion, production deployment record, certification report, or Founder decision. Open T1C rows remain open until independently adjudicated.

Evidence boundary: every conclusion must link to a package file, register row, source-review finding ID, validation report, or detached archive checksum. Absence of evidence must be recorded as open rather than inferred as remediated.
