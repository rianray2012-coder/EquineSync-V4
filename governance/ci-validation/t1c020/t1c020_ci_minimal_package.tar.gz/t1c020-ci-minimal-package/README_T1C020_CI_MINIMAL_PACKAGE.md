# T1C-020 CI Minimal Evidence Package

This package contains the files required to run the V18 closure-aware validator on Ubuntu for T1C-020 platform reproduction evidence.

It is not the full package tree. It is a minimal validator-dependency bundle used because local cloud-backed full package archiving and Docker full-package reads were unreliable.
