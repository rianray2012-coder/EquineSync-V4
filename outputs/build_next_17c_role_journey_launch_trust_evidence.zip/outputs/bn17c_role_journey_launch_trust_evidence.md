# BN17C Role Journey + Launch Trust Evidence

Status: Codex-reviewed and locked; BN17D cleanup required.

Date: 2026-07-04

## Purpose

BN17C is the first evidence pass after locked BN17B. It verifies that the
post-login, first-login, dashboard, nav, direct URL, privacy, provider, copy,
and feature-shell behavior matches the current launch roadmap.

BN17C is not a feature phase. It should not build the Trainer Operating Center,
Service Provider workflow, property maps, AI assistant, community help log,
marketplace features, new payments, or new provider integrations.

No runtime behavior was changed for BN17C.

## Current Baseline

- Current locked phase: BN17B.
- Current locked evidence phase: BN17C.
- Cleanup phase opened by this evidence: BN17D.
- Launch path after BN17C/17D: BN18A, BN18B, BN18C, BN19, BN20/BN12 closure,
  BN21 pilot go/no-go, BN22 public launch gate.

Evidence method:

- Source review of `frontend/src/App.js`.
- Source review of `frontend/src/lib/roleLanding.js`.
- Source review of `frontend/src/lib/roleNavigation.js`.
- Source review of role dashboard components under
  `frontend/src/features/dashboards/`.
- Source review of backend scoping surfaces in `backend/routes/horses.py`,
  `backend/routes/horse_ledger.py`, and `backend/routes/billing.py`.
- Production-facing copy scan with `rg`.
- Focused BN16/17 source-level regression tests.

## Role Evidence Matrix

| Role | Expected post-login / dashboard | BN17C status |
| --- | --- | --- |
| `admin` / facility admin | `/setup/facility` if setup-incomplete, otherwise `/dashboard/facility` | Pass for route resolver and dashboard gate; BN17D must review direct access to legacy operational routes. |
| `barn_owner` | `/setup/facility` if setup-incomplete, otherwise `/dashboard/facility` | Pass for route resolver and dashboard gate; BN17D must review direct access to legacy operational routes. |
| `barn_manager` | `/setup/facility` if setup-incomplete, otherwise `/dashboard/manager` | Pass for route resolver and dashboard gate; BN17D must verify pending-review restrictions and direct legacy route access. |
| `trainer` | `/role-intake/trainer` if intake-incomplete, otherwise `/dashboard/trainer` | Pass for route resolver and dashboard gate. Trainer dashboard is still a general Stable Command wrapper, so trainer operating-center depth remains deferred. |
| `groom` | `/role-intake/staff` if intake-incomplete, otherwise `/dashboard/staff` | Pass for route resolver and dashboard gate. |
| `working_student` | `/role-intake/staff` if intake-incomplete, otherwise `/dashboard/staff` | Pass for route resolver and dashboard gate. |
| `horse_owner` | `/role-intake/owner` if intake-incomplete, otherwise `/dashboard/owner` | Pass for safe dashboard shell. Owner Portal CTA remains disabled pending backend-authoritative linkage. Direct legacy route access needs BN17D review. |
| `parent` / guardian | `/role-intake/guardian` if intake-incomplete, otherwise `/dashboard/guardian` | Pass for safe dashboard shell. Direct legacy route access needs BN17D review. |
| `rider` | `/role-intake/rider` if intake-incomplete, otherwise `/dashboard/rider` | Pass for safe dashboard shell. Direct legacy route access needs BN17D review. |
| `service_provider` | `/dashboard/service-provider` | Pass for safe empty dashboard shell and nav. Direct legacy route access needs BN17D review. |
| `veterinarian` | `/dashboard/service-provider` | Pass for safe empty dashboard shell and nav. Direct legacy route access needs BN17D review. |
| `farrier` | `/dashboard/service-provider` | Pass for safe empty dashboard shell and nav. Direct legacy route access needs BN17D review. |
| `platform_admin` | `/admin/portal/dashboard` | Pass for platform route separation. Platform admin must still not be assumed to have barn membership for product data. |
| `support_admin` | allowed platform support surfaces only | Admin Portal role caps are preserved; BN18/BN19 should confirm live UAT. |
| `billing_admin` | allowed platform billing surfaces only | Admin Portal role caps are preserved; BN18/BN19 should confirm live UAT. |

## Direct URL Denial Evidence

Confirmed clean:

- `/dashboard/facility`, `/dashboard/manager`, `/dashboard/staff`,
  `/dashboard/trainer`, `/dashboard/owner`, `/dashboard/guardian`,
  `/dashboard/rider`, and `/dashboard/service-provider` are direct URL
  role-gated through `permit(...)`.
- `/admin/portal/*` remains separated from product routes.
- `/setup/facility` is protected by setup visibility logic and descendant-path
  redirect protection from BN17A.

Finding `BN17D-ROUTE-1`:

Several legacy product routes remain plain authenticated routes inside
`AppShell`, not role/capability-gated routes:

- `/today`
- `/horses`
- `/horses/:id`
- `/owners`
- `/riders`
- `/lessons`
- `/training`
- `/health`
- `/stall-rest`
- `/medications`
- `/turnout`
- `/feed`
- `/inventory`
- `/incidents`
- `/messaging`
- `/settings`
- `/billing/success`

Backend scoping protects many data paths, but launch trust needs direct-route
behavior to match role intent. BN17D should add explicit role/capability gates
or safe redirects for these legacy routes, with special attention to owner,
guardian, rider, service-provider, pending-review, and platform-admin contexts.

## Owner / Guardian / Rider Safety Evidence

Clean evidence:

- Owner, guardian, and rider dashboards render `PersonalDashboard`, not the
  intake surface.
- `PersonalDashboard` has no runtime API calls.
- Owner dashboard keeps `Owner Portal Pending` disabled and does not link
  directly to `/owner-portal`.
- HorseOps owner projection code preserves owner-safe shaping, including
  `primary_owner_id`, legacy `owner_id`, and `secondary_owner_ids`.
- Billing invoice list scopes owner reads by `owner_id=user["id"]`.

Finding:

- Core `/horses` and `/horses/:id` use account/barn filtering but not an
  owner-role projection in the route itself. If owners, parents, riders, or
  service providers can direct-navigate to those pages, route-level gating or a
  role-safe read path is needed in BN17D before launch acceptance.

## Service Provider Safety Evidence

Clean evidence:

- Service provider, veterinarian, and farrier roles resolve to
  `/dashboard/service-provider`.
- Service provider dashboard is a safe empty shell with no runtime API calls.
- Service provider nav does not expose all-horse, owner-list, billing, reports,
  or admin routes by default.

Finding:

- Direct legacy route access still needs BN17D review for `/horses`,
  `/messaging`, `/settings`, and other product routes that are only protected
  by login at the frontend route level.

## Trainer Adequacy Evidence

Clean evidence:

- Trainer incomplete intake resolves to `/role-intake/trainer`.
- Trainer complete role resolves to `/dashboard/trainer`.
- Trainer dashboard route is role-gated to `trainer`.
- Trainer nav exposes Tasks, Horses, Schedule, Health Alerts, Owner Requests,
  Program Facility, Reports, Messages, and Settings.

Launch adequacy note:

- The trainer dashboard currently wraps the general Stable Command dashboard.
  This is acceptable only if founder accepts a pilot-level trainer surface.
  The full Trainer Operating Center remains deferred.

## Pending-Review Account Evidence

Evidence:

- `account_memberships` pending-review semantics exist in backend support code.
- `AppShell` contains pending-review banner behavior.

Finding:

- BN17C did not prove every legacy direct route blocks pending-review users.
  This should be part of BN17D/BN18C evidence before founder acceptance.

## Production Copy Scan

Finding `BN17D-COPY-1`:

- `frontend/src/components/onboarding/StaffStep.jsx` contains production-facing
  copy: `Email delivery is in dev mode`.
- The same component references `backend/.env` and copying a magic link.
- `frontend/src/components/NotificationPrefsCard.jsx` says `push is coming soon`.
- `frontend/src/pages/admin/AdminTopbar.jsx` still says `Search... (coming in
  Admin-2)`.
- `frontend/src/pages/FeatureWorkspace.jsx` contains `workflow shell` copy.
- `frontend/src/pages/FormsSignatures.jsx` references live envelope sending
  remaining gated to a later phase.

Some role-intake copy intentionally describes intake/setup. BN17D should not
remove that wholesale; it should clean only launch-facing dev/phase/shell copy.

## Calm Tone Scan Targets

Preserve existing calm-copy restrictions around:

- `Conflict`
- `Reject`
- `Deny`
- `Action Required`
- `Urgent`
- `Warning:`
- `Error`

BN17C did not find a need to change calm-tone policy in this evidence phase.

## Feature-Shell Exposure Review

Finding `BN17D-FEATURE-1`:

Feature-shell surfaces and copy should be reviewed before founder launch
acceptance. BN17D should classify each exposed shell as keep, hide, relabel, or
move to setup/readiness. Candidate areas:

- Admin topbar search placeholder.
- Forms & Signatures later-phase copy.
- Generic `FeatureWorkspace` workflow-shell copy.
- Notification delivery language for push/Text/SMS.
- Any deterministic review queue or integration readiness surface that implies
  live automation without provider-live proof.

## P0 Scoping Smoke Checks

Evidence:

- HorseOps owner-safe projection exists and checks `primary_owner_id`,
  `owner_id`, and `secondary_owner_ids`.
- Billing invoice reads scope horse-owner rows by `owner_id`.
- Admin Portal separation remains intact at the route namespace level.

Open:

- Owner-safe horse list behavior through the legacy `/horses` UI needs BN17D
  route-gate review.
- QuickBooks export and finance export scoping were not re-proven in BN17C.
  Keep them in BN18C/BN19 launch evidence if exposed to UAT.
- Invite dev-link copy is present in onboarding source and needs BN17D cleanup.

## Current Findings

1. `BN17D-ROUTE-1` - legacy product routes are protected by login but not
   uniformly role/capability-gated at the frontend route level.
2. `BN17D-COPY-1` - production UI source still contains dev-mode, backend
   `.env`, coming-soon, workflow-shell, and later-phase language.
3. `BN17D-FEATURE-1` - exposed feature-shell surfaces need a keep/hide/relabel
   classification before founder launch acceptance.
4. `BN17D-SCOPE-1` - owner, guardian, rider, service-provider, and
   pending-review direct-route behavior needs credentialed evidence after
   route cleanup.

## BN17D Candidate Fixes

Open BN17D as a targeted cleanup phase:

- Add direct-route role/capability guards or safe redirects for legacy product
  routes.
- Clean production-facing dev/phase/shell copy.
- Classify and hide/relabel feature-shell surfaces.
- Add focused source guards and, where safe, browser/UAT evidence for
  direct-route denial.

## Launch Blockers Still Open

- BN17D cleanup has not yet been executed.
- Provider-live proof not yet refreshed in BN18A.
- Production environment proof not yet refreshed in BN18B.
- UAT role refresh not yet rerun after BN17B.
- Founder acceptance ledger not yet updated after BN17C/BN18 evidence.
- Do not mark any row founder-accepted from BN17C alone.

## Deferred Roadmap Preserved

Trainer Operating Center, full Service Provider workflow, property/maps,
community help log, DocuSign live-signing expansion, AI assistant, billing
expansion, messaging expansion, reporting expansion, and Text/SMS notifications
remain deferred unless a launch blocker requires a narrow fix.
