# BN15F.1 Screenshot Inventory

Captured:

- `uat-r1-platform-admin.png`
- `uat-r2a-facility-admin.png`
- `uat-r2a-facility-admin-dashboard-top.png`
- `uat-r2a-facility-admin-dashboard-pulse.png`
- `uat-r2b-barn-owner.png`
- `uat-r2b-barn-owner-dashboard-top.png`
- `uat-r2b-barn-owner-dashboard-pulse.png`
- `uat-r3-barn-manager-dashboard-top.png`
- `uat-r3-barn-manager-dashboard-pulse.png`
- `uat-r4a-groom.png`
- `bn13m-t1-trainer.png`
- `bn13m-w1-working-student.png`
- `uat-r5-horse-owner.png`
- `uat-r6-guardian-parent.png`
- `uat-r7-rider.png`
- `uat-r8-individual-owner.png`

Still pending safe credentialed sessions:

- None. TP-1 through TP-10 role screenshots are captured for this BN15F.1 pass.

Do not copy older BN15D or BN13O screenshots into this folder unless the phase
is intentionally downgraded from fresh live evidence to reference evidence.
