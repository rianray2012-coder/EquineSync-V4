"""Build-Next-16C - frontend route separation guards.

BN16C keeps the locked BN16B backend readiness contract intact and makes the
frontend name the three journeys separately: facility setup, role intake, and
live dashboards. These are source-level guards because the phase is route/UI
wiring only.
"""
from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend" / "src"


def _read(path: Path) -> str:
    return path.read_text()


def test_role_landing_names_setup_and_intake_routes_without_deleting_legacy_role_home_paths():
    src = _read(FRONTEND / "lib" / "roleLanding.js")

    assert 'export const SETUP_ROUTE = "/setup/facility";' in src
    assert 'export const LEGACY_SETUP_ROUTE = "/onboarding";' in src
    assert 'rider: "/role-home/rider"' in src
    assert 'barnOwner: "/role-home/barn-owner"' in src

    for key, path in {
        "rider": "/intake/rider",
        "guardian": "/intake/guardian",
        "owner": "/intake/owner",
        "barnOwner": "/intake/facility-founder",
        "trainer": "/intake/trainer",
        "manager": "/intake/manager",
        "staff": "/intake/staff",
    }.items():
        assert f'{key}: "{path}"' in src


def test_post_login_resolver_uses_explicit_setup_and_intake_paths():
    src = _read(FRONTEND / "lib" / "roleLanding.js")

    assert 'return shouldRouteToFacilitySetup(user) ? SETUP_ROUTE : ROLE_HOME_PATHS.facilityAdmin;' in src
    assert 'if (shouldRouteToFacilitySetup(user)) return SETUP_ROUTE;' in src
    assert "return ROLE_INTAKE_PATHS.trainer;" in src
    assert "return ROLE_INTAKE_PATHS.manager;" in src
    assert "return ROLE_INTAKE_PATHS.staff;" in src
    assert "return ROLE_INTAKE_PATHS.guardian;" in src
    assert "return ROLE_INTAKE_PATHS.rider;" in src
    assert "return horseId ? `/owner/horses/${horseId}` : ROLE_INTAKE_PATHS.owner;" in src
    assert 'SETUP_READINESS_ROLES = ["admin", "barn_owner", "barn_manager"]' in src
    assert 'SETUP_ELIGIBLE_ROLES = ["admin", "barn_owner"]' in src


def test_app_routes_setup_facility_and_intake_aliases_through_app_shell():
    src = _read(FRONTEND / "App.js")

    assert 'path="/setup/facility" element={<SetupProtected><Onboarding /></SetupProtected>}' in src
    assert 'path="/onboarding" element={<Navigate to={SETUP_ROUTE} replace />}' in src
    assert 'path="/role-home/:profile" element={<RoleHome />}' in src

    for path, profile in {
        "/intake/facility-founder": "barn-owner",
        "/intake/manager": "manager",
        "/intake/staff": "staff",
        "/intake/trainer": "trainer",
        "/intake/owner": "owner",
        "/intake/guardian": "guardian",
        "/intake/rider": "rider",
    }.items():
        assert f'path="{path}" element={{<RoleHome forcedProfile="{profile}" />}}' in src


def test_setup_protected_reads_backend_readiness_before_rendering_setup():
    src = _read(FRONTEND / "App.js")

    assert 'api.get("/onboarding/readiness")' in src
    assert "state.error?.response?.status === 403" in src
    assert "React.cloneElement(children, { setupReadiness: state.readiness })" in src
    assert 'data-testid="setup-readiness-error"' in src


def test_onboarding_consumes_readiness_and_preserves_barn_manager_view_only_boundary():
    src = _read(FRONTEND / "pages" / "Onboarding.jsx")

    assert "export default function Onboarding({ setupReadiness = null })" in src
    assert 'api.get("/onboarding/readiness")' in src
    assert 'data-testid="setup-readiness-panel"' in src
    assert "readiness?.can_finalize !== false" in src
    assert "Only a facility admin or barn owner can launch setup." in src
    assert "status === 409" in src
    assert "setReadiness(detail)" in src


def test_setup_concierge_links_to_named_facility_setup_route():
    src = _read(FRONTEND / "components" / "dashboard" / "SetupConciergeCard.jsx")

    assert 'to="/setup/facility"' in src
    assert 'to="/onboarding"' not in src


def test_setup_entry_points_use_named_setup_route_not_legacy_onboarding_navigation():
    role_nav = _read(FRONTEND / "lib" / "roleNavigation.js")
    accept_invite = _read(FRONTEND / "pages" / "AcceptInvite.jsx")
    settings = _read(FRONTEND / "pages" / "Settings.jsx")

    assert 'import { SETUP_ROUTE } from "./roleLanding";' in role_nav
    assert role_nav.count('item(SETUP_ROUTE, "Setup", "sparkles")') == 2
    assert '"/onboarding"' not in role_nav

    assert 'import { SETUP_ROUTE } from "../lib/roleLanding";' in accept_invite
    assert "navigate(SETUP_ROUTE, { replace: true })" in accept_invite
    assert 'navigate("/onboarding"' not in accept_invite

    assert 'import { SETUP_ROUTE } from "../lib/roleLanding";' in settings
    assert 'api.post("/onboarding/reset")' in settings
    assert "navigate(SETUP_ROUTE)" in settings
    assert 'navigate("/onboarding"' not in settings


def test_role_home_can_render_alias_profiles_from_forced_profile_prop():
    src = _read(FRONTEND / "pages" / "RoleHome.jsx")

    assert "export default function RoleHome({ forcedProfile })" in src
    assert "const { profile: routeProfile } = useParams();" in src
    assert "const profile = forcedProfile || routeProfile;" in src
