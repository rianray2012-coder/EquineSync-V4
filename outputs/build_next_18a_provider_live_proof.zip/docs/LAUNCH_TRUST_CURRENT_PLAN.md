# Launch Trust Current Plan

Date: 2026-07-05

## Current Position

BN17C is locked. BN17D targeted cleanup is Codex-reviewed and locked. BN18A
provider-live proof is Codex-reviewed and locked.

Locked state:

- BN17A separated launch-trust route taxonomy for setup, intake, and dashboards.
- BN17B separated role-intake rendering from live dashboard rendering.
- Owner, guardian, and rider dashboards now render dashboard-language shells
  instead of role-intake forms.
- The owner dashboard CTA is intentionally disabled as `Owner Portal Pending`
  until a backend-authoritative owner/facility/horse connection exists.

Launch state:

- EquineSync is not yet at final launch clearance.
- BN17C has been executed and locked as an evidence-first launch-trust pass.
- BN17D has executed the concrete direct-route, copy, feature-shell, and nav
  cleanup items from BN17C.
- The next correct phase is BN18B production environment proof.
- Broad feature expansion remains deferred.

## Status Drift To Reconcile

The repo supports BN17B as locked through `BUILD_NEXT_17B_ROLE_INTAKE_SPLIT_README.md`
and `memory/PRD.md`.

Known documentation drift to reconcile before final launch closure:

- `memory/PRD.md` and `BUILD_NEXT_14B_ROLE_UX_HARDENING_CLEANUP_README.md`
  still describe BN14B as ready for review, even though later work proceeded
  past BN14B.
- `memory/PRD.md` and
  `BUILD_NEXT_15F1_CREDENTIALED_LIVE_TODAYS_PULSE_WALKTHROUGH_README.md`
  still describe BN15F.1 as ready for review, even though credentialed role
  screenshots were captured and later phases proceeded.

These are documentation reconciliation items, not current runtime blockers.

## Non-Expansion Directive

Do not start the full Trainer Operating Center, full Service Provider workflow,
full property/maps system, AI assistant layer, community help log, public
marketplace, or new billing/payment behavior until the launch-trust evidence
chain is clean.

## Preserved Architecture Decisions

- FastAPI remains assembled in `backend/server.py` from domain router factories.
- `backend/core/` remains shared infrastructure and should not import
  `server.py`.
- Product routers preserve active-facility gating where applied.
- `task_engine.py` remains the canonical operational task engine.
- Admin Portal remains platform-admin-only and separate from barn-scoped
  product routes.
- Barn-scoped `user.role` and platform-level `user.platform_role` remain
  separate authority domains.
- QuickAddSheet, SoftWarning, AppShell, role-driven Sidebar, product tokens,
  admin tokens, typography, and the running-horse brand mark remain preserved.
- The horseshoe icon request applies to the Horses nav item only, not the brand
  mark.

## Launch Path

### BN17C - Post-BN17B Role Journey + Launch Trust Evidence Pass

Evidence-only. Verify role landing, first-login state, dashboards, nav,
direct URL denials, owner/guardian/rider safety, service-provider safety,
trainer adequacy, pending-review restrictions, copy, feature-shell exposure,
and P0 scoping checks.

Status: Codex-reviewed and locked with findings.

Output:

- `outputs/bn17c_role_journey_launch_trust_evidence.md`
- `outputs/build_next_17c_role_journey_launch_trust_evidence.zip`

### BN17D - Targeted Role Journey / Dashboard / Nav / Scoping Cleanup

Only execute if BN17C finds mismatches. Fixes must be surgical and tied to
evidence findings.

Status: Codex-reviewed and locked. BN17D added explicit frontend role gates for
legacy product routes, cleaned BN17C-flagged production copy, classified
feature-shell exposure, and hid unsafe owner/guardian/provider links into
operational messaging.

Output:

- `outputs/bn17d_role_journey_cleanup_evidence.md`
- `outputs/build_next_17d_role_journey_cleanup.zip`

### BN18A - Provider-Live Proof

Verify Stripe, Resend, DocuSign, and other integration labels against actual
production-like behavior. Hide, relabel, or defer anything that is not live.

Status: Codex-reviewed and locked. BN18A adds a scrubbed provider proof report
and source guards that distinguish configured providers from live/prod-like
proof. It performs no provider calls, no Mongo reads/writes, and no founder
acceptance. Round-1 fixes tightened DocuSign live REST-base recognition and
Resend sender-domain proof so custom DocuSign URLs or non-`equine-sync.com`
senders cannot pass provider readiness. Codex re-review found no remaining
BN18A issues. The current local report is `deferred` with 0 blockers and 7
warnings; it does not replace BN18B production environment proof.

Output:

- `outputs/bn18a_provider_live_proof_report.md`
- `outputs/build_next_18a_provider_live_proof.zip`

### BN18B - Production Environment Proof

Verify Vercel, Render, Atlas, health, CORS, environment variables, rollback,
backups, monitoring, background loops, and production seed safety.

### BN18C - UAT Role Refresh

Run safe role-based UAT after BN17C/17D and BN18A/18B evidence are complete.

### BN19 - Founder Acceptance Ledger

Mark no row accepted unless evidence exists and founder acceptance is explicit.

### BN20 / BN12 Closure - Final Launch Closure Package

Reconcile PRD, ROADMAP, current launch docs, readmes, and all evidence outputs.
Produce a final go/no-go recommendation.

### BN21 - First-Client Pilot Go/No-Go

Pilot cannot proceed with open P0 privacy/scoping issues, unresolved seed-data
risk, missing rollback/support/monitoring, or unaccepted provider-live status.

### BN22 - Public Launch Gate

Public launch follows clean pilot evidence and founder sign-off.

## Immediate Next Step

Proceed to BN18B production environment proof.
