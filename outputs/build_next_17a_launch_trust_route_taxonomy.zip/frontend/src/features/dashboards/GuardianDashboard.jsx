import RoleHome from "../../pages/RoleHome";

export default function GuardianDashboard() {
  return <RoleHome forcedProfile="guardian" />;
}
