import RoleHome from "../../pages/RoleHome";

export default function OwnerDashboard() {
  return <RoleHome forcedProfile="owner" />;
}
