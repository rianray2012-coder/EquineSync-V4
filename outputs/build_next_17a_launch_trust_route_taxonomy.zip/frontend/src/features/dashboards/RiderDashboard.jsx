import RoleHome from "../../pages/RoleHome";

export default function RiderDashboard() {
  return <RoleHome forcedProfile="rider" />;
}
