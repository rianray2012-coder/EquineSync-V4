# BN17D Role Journey Cleanup Evidence

Status: Codex-reviewed and locked.

Date: 2026-07-04

## Purpose

BN17D closes the concrete cleanup findings opened by BN17C while preserving the
launch-trust gate sequence.

No new product behavior.
No backend route/schema/auth/permission/privacy changes.

## BN17D-ROUTE-1

The legacy product routes that BN17C identified as plain authenticated routes
now use explicit frontend role gates through `BN17D_DIRECT_ROUTE_ROLES` in
`frontend/src/App.js`.

Covered routes:

- `/today`
- `/horses`
- `/horses/:id`
- `/owners`
- `/riders`
- `/lessons`
- `/training`
- `/health`
- `/stall-rest`
- `/medications`
- `/turnout`
- `/feed`
- `/inventory`
- `/billing/success`
- `/incidents`
- `/messaging`
- `/settings`

Result:

- Owner, guardian, rider, service-provider, and platform-admin direct access to
  operational legacy routes now fails at the frontend role gate unless that
  role is explicitly included.
- Product dashboard routes from BN17A/BN17B remain unchanged.
- Admin Portal routes remain separate under `/admin/portal/*`.

## BN17D-COPY-1

Flagged launch-hostile copy was cleaned in the exact BN17C target files:

- `StaffStep.jsx`: removed dev-mode, local env, and magic-link wording while
  preserving the secure invite fallback.
- `NotificationPrefsCard.jsx`: removed push-coming-soon language and retained
  Inbox plus Email as separate delivery-channel controls.
- `AdminTopbar.jsx`: relabeled disabled search to neutral `Search`.
- `FeatureWorkspace.jsx`: removed workflow-shell language from empty state.
- `FormsSignatures.jsx`: removed later-phase envelope-sending wording and
  replaced it with provider-enabled readiness copy.

## BN17D-FEATURE-1

Feature-shell classification:

| Surface | Classification |
| --- | --- |
| Admin search | Keep disabled, relabeled neutral. |
| Staff invite fallback | Keep, production-safe copy. |
| Notification channels | Keep Inbox and Email; hide future channels until configured. |
| FeatureWorkspace empty state | Keep, relabeled readiness-safe. |
| Forms & Signatures provider readiness | Keep, provider-enabled copy. |
| Owner/guardian/provider Messaging nav | Hide until role-specific messaging expansion exists. |

## BN17D-SCOPE-1

Owner, guardian, unknown/default, and service-provider navigation no longer
links directly to `/messaging`, because the existing messaging page is an
operational barn surface with write behavior and recipient visibility controls.

Operational messaging remains visible to:

- `admin`
- `barn_owner`
- `barn_manager`
- `trainer`
- `groom`
- `working_student`

Credentialed direct URL evidence remains a BN18C/UAT item; BN17D adds the
source-level route and nav contract.

## Preserved Boundaries

- No backend route/schema/auth/permission/privacy changes.
- No owner projection changes.
- No alert/history/service-request/audit behavior changes.
- No billing, Stripe, Resend, DocuSign, SMS/Text, Admin Portal capability,
  HorseOps, landing-page, seed, UAT account, founder-accepted, pilot, or
  public-launch changes.

## Verification

Completed locally:

- Focused BN6/BN16/BN17 source-level suite: 45/45 passed.
- Frontend production build: compiled successfully.
- Codex lock review: 45/45 focused tests passed; zip integrity passed.

Focused tests:

- `backend/tests/test_build_next_6_signature_connector.py`
- `backend/tests/test_build_next_16b_setup_readiness_contract.py`
- `backend/tests/test_build_next_16c_frontend_route_separation.py`
- `backend/tests/test_build_next_17a_launch_trust_route_taxonomy.py`
- `backend/tests/test_build_next_17b_role_intake_split.py`
- `backend/tests/test_build_next_17c_role_journey_launch_trust_evidence.py`
- `backend/tests/test_build_next_17d_role_journey_cleanup.py`

Expected package:

- `outputs/build_next_17d_role_journey_cleanup.zip`

## Next Step

After BN17D locks, proceed to BN18A provider-live proof.
