# Launch Trust Master Fix List

Date: 2026-07-04

This is the running launch-trust tracker from current BN17B state through
pilot and public launch. It is intentionally evidence-first and avoids feature
expansion.

## Completed

- BN17D locked: targeted role journey cleanup completed for
  BN17C findings `BN17D-ROUTE-1`, `BN17D-COPY-1`, `BN17D-FEATURE-1`, and
  source-level `BN17D-SCOPE-1` nav cleanup.
- BN17C locked: post-BN17B role journey and launch-trust evidence pass
  completed with BN17D follow-up findings.
- BN17B locked: role intake split and copy cleanup.
- BN17A locked: setup, role-intake, and dashboard route taxonomy.
- BN16A-C locked: role journey audit, backend setup readiness contract, and
  frontend route separation.
- BN15A-F locked: Today's Pulse contract, frontend wiring, visibility policy,
  evidence ledger, and live walkthrough packet.
- BN13A-P locked: role routing, role navigation, intake shells, screenshot
  evidence, and Title Case polish.
- Admin Portal, HorseOps, Stripe 15R, DocuSign BN6, and minor/parent safeguard
  foundations remain preserved as prior locked work.

## P0 Launch Blockers

- Direct URL denial evidence must be refreshed after BN17D for sensitive
  product and admin routes.
- Owner, guardian, rider, and service-provider data scoping must be verified
  from backend responses, not nav visibility alone.
- Provider-live status must be proven for Stripe, Resend, and DocuSign or
  founder-accepted as hidden/deferred.
- Production seed safety must be verified. `seed_data.py` must not create demo,
  fake, test, or sample tenant data in production.
- Production environment proof must confirm background loops, deploy markers,
  rollback, monitoring, backups, CORS, and health.
- Founder acceptance ledger must remain unaccepted until explicit founder
  acceptance is recorded.

## P1 Pilot Blockers

- BN14B and BN15F.1 status drift must be reconciled before final launch closure.
- Soft-warning subscription enforcement via UsageMeter needs founder acceptance
  for pilot and separate acceptance for public launch if hard 402 enforcement
  remains deferred.
- Feature-shell exposure must be reviewed so daily users do not see unfinished
  surfaces as live features.
- Pending-review marketplace roles must be verified so trainer, barn owner, and
  service-provider candidates cannot access privileged operational data before
  approval/invitation.
- Service-provider, veterinarian, and farrier role dashboards must land safely
  and avoid all-horse, owner-list, billing, staff schedule, reports, or admin
  exposure.
- Live invite/email behavior must be verified so production never exposes
  magic dev links, backend `.env` instructions, or local-only accept URLs.
- Finance/export scoping must be checked for owner billing, QuickBooks export,
  and barn-scoped invoice/account data.

## P2 Polish

- Keep role/dashboard titles in consistent Title Case.
- Keep product pages on product tokens and Admin Portal pages on admin tokens.
- Preserve calm copy rules and avoid production-facing phase/readiness language.
- Continue replacing ambiguous feature-shell labels with readiness-safe or
  hidden states.
- Keep screenshot/evidence filenames stable for review packages.

## Deferred Roadmap

- Trainer Operating Center: multi-facility trainer context, lesson programs,
  training packages, haul-in clients, school horses, trainer billing, trainer
  documents, and trainer dashboard expansion.
- Service Provider / Care Partner workflow: provider dashboard, appointment
  notes, assigned-horse access, invoice upload, license/insurance tracking.
- Property / Location / Map System: stall/turnout/pasture maps, temporary
  locations, location history, print/share modes.
- Community Help Log: reviewed owner/rider/staff help records with safe
  permission boundaries.
- DocuSign Live Signing expansion: templates, sending, embedded signing,
  webhook status, signed-document metadata, and portal visibility.
- AI Assistant Layer: onboarding import assistant, missing-data detector,
  approved-fact drafts, and no autonomous diagnosis/sending/billing/mutation.
- Billing and payments expansion: owner invoice create/send/pay, refunds,
  QuickBooks sync, add-on management, and hard limit enforcement.
- Messaging expansion: recipients, threads, read receipts, guardian-safe minor
  messaging, and real delivery logs.
- Reporting expansion: real PDF/XLSX exports and role-specific reports.
- Text/SMS notifications: opt-in, quiet hours, compliance-safe unsubscribe,
  phone verification, provider configuration, and rate limits.

## Moot / No-Action Items

- Settings notification controls for EquineSync Inbox and Email are not
  duplicates; they are separate delivery-channel controls.
- The running-horse brand mark should not be replaced by the Horses nav
  horseshoe icon.
- Barn admins are not platform admins.
- Platform admins are not automatically barn members.
- Nav visibility alone is not a security boundary.

## Canonical System Decisions

- Task Engine is canonical for operational tasks.
- `/inventory` should remain canonical inventory unless Supply Inventory is
  explicitly merged or hidden.
- `owner_updates` is canonical for owner-facing update lifecycle.
- `document_signatures` is canonical for document/signature workflows.
- Owner-safe endpoints must be canonical for owner horse lists.
- Stable IDs are canonical for access control.
- Names are display labels only.
- Barn-scoped `user.role` and platform-level `user.platform_role` are separate
  authority domains.
- Product facility gates do not replace role/capability checks.

## Split-Truth Items To Track

- Task Engine vs feature-module Staff Tasks.
- Inventory vs Supply Inventory.
- Real `owner_updates` vs feature-module owner media updates.
- `document_signatures` vs feature-module Forms & Signatures.
- Staff self-service My Work vs admin/manual Staff Scheduling/Time Clock by
  name.
- Billing invoice backend vs payment/autopay readiness modules.
- Integration readiness vs UI labels implying live connections.

## Open Founder Decisions

- Is soft-warning subscription overage acceptable for pilot only, or also for
  public launch?
- Which provider integrations are fully live, pilot-acceptable, blocked, or
  hidden/feature-flagged?
- Which non-launch limitations are explicitly accepted for pilot?
- Which UAT rows may be marked founder-accepted after BN17C/18 evidence?
- What support SLA and rollback posture is required for the first-client pilot?

## Required Evidence

- BN17C role landing, dashboard, nav, direct-denial, scoping, copy, and
  feature-shell evidence. Status: captured and locked.
- BN17D fix evidence for concrete BN17C findings. Status: captured and locked.
- BN18A provider-live proof.
- BN18B production environment proof.
- BN18C UAT role refresh.
- BN19 founder acceptance ledger.
- BN20 / BN12 launch closure package.
- BN21 first-client pilot go/no-go.
- BN22 public launch gate.
