# EquineSync Launch Trust Master Fix List

Date: 2026-07-05

This is the canonical launch-trust blocker and evidence list between the current locked BN18B/BN18C state and public launch.

## Completed And Locked

- BN17C - Role Journey + Launch Trust Evidence Pass.
- BN17D - Targeted Cleanup.
- BN18A - Provider-Live Proof.
- BN18B - Production Environment Proof.
- BN18C - UAT Role Refresh.
- BN18D - Field Reliability / Offline Source Proof. Founder online-first /
  limited-field-recovery positioning accepted and locked.

BN18B and BN18C are considered locked after the refreshed production API and role evidence passes reported zero blockers and zero warnings.

## P0 Launch Blockers

1. BN18E App Store / Google Play readiness proof is missing.
   - Public launch cannot claim mobile-store readiness without documented store metadata, privacy, support, billing, review, and release evidence.

2. Founder acceptance ledger is not final.
   - BN19 must include BN18D and BN18E evidence before it can be complete.

3. Demo/test seed data must remain excluded from production customer records.
   - No pilot if demo/test seed accounts or fixture data can contaminate production customer workflows.

4. Role and facility privacy must remain backend-authoritative.
   - No public launch if owner, provider, staff, guardian, rider, admin, or cross-facility data leaks.

5. Provider live-state claims must remain accurate.
   - Stripe, Resend, DocuSign, and future provider surfaces must not present as live unless the target environment is configured and verified.

6. Direct URL bypasses must remain blocked.
   - Dashboard/onboarding/role-home separation must not allow users to reach surfaces outside their accepted role, facility, or setup status.

7. Minor/guardian safeguards must remain enforced.
   - Parent/guardian, rider, lesson participant, and minor communication boundaries remain launch-critical.

## Accepted BN18D Field-Reliability Posture

Founder accepted the following pilot posture:

- EquineSync is an online-first web platform with limited field recovery.
- Narrow queued retry/idempotency may be claimed only for task complete, task
  skip, and bulk complete where source proof exists.
- Local draft preservation may be claimed only for QuickAdd and HorseOps forms
  where source proof exists.
- Most admin, provider, billing, owner, medical, safety, daily-care note,
  incident, and service-request workflows remain online-only or partial unless a
  later implementation phase expands them.

Launch copy must not claim:

- Full offline app support.
- Universal cached reads.
- Universal queued writes.
- Service-worker / PWA offline app shell.
- IndexedDB-backed universal outbox.
- Broad conflict-review UI.
- Provider offline support.

Founder trust constraint: poor-signal barn, arena, truck, and field use is a
trust-critical risk. Work loss or ambiguous save/retry/draft state in weak
signal would damage user trust, so field reliability remains a high-priority
post-BN18D track even though full offline support is deferred.

## P1 Pilot Blockers

1. Future field-reliability expansion should prioritize weak-signal workflows for:
   - Today tasks.
   - Task completion/skip/bulk completion.
   - Daily care checks.
   - Feed, water, hay, bedding, medication, incident, and shift notes.
   - Owner requests.
   - Provider visit notes and documents.
   - Facility dashboard and staff workflow surfaces.

2. BN18E evidence must clarify:
   - Whether the pilot is web-only, PWA-assisted, or native app-store distributed.
   - Whether Apple/Google billing policy affects subscription flows.
   - Whether store metadata and privacy labels are complete.

3. UAT screenshots should stay current after any dashboard, onboarding, role-home, or navigation change.

4. Monitoring, backup, rollback, and deploy-marker evidence must remain current after each production deploy.

5. Email verification policy must remain explicit for pilot.

## P2 Polish And Follow-Up

- Copy consistency for role titles and role-home headings.
- Additional role screenshots after visual polish.
- Optional SMS notification delivery method planning. Email and EquineSync Inbox notification settings are intentionally separate controls, not duplicates.
- App-store marketing screenshot polish after BN18E.
- Future offline UX improvements after BN18D acceptance.

## Deferred Roadmap

- Full native mobile app implementation, unless BN18E changes the distribution strategy.
- Full service-worker/PWA offline app shell if BN18D classifies launch as online-only with accepted limitations.
- Advanced sync conflict dashboard beyond launch-critical workflows.
- Public marketplace/provider ecosystem.
- Inventory purchasing, vendor ordering, and cost accounting expansions.
- Advanced analytics and cross-facility trust dashboards.

## Canonical System Decisions

- Role journeys remain separated from setup/onboarding flows.
- Dashboard access must not imply setup completion.
- Owner/provider/staff privacy must be enforced by backend response shape, not client filtering alone.
- Billing surfaces must separate web Stripe billing from Apple/Google app-store billing policy.
- Production evidence must be from the target live/staging environment, not only local screenshots.
- Demo/test seed data must be tagged and excluded from customer truth.
- Field-reliability behavior must be explicit: online-only, draft-only, queued, or fully synced.

## Founder Decisions Needed

1. Is first-client pilot web-only, PWA-assisted, or app-store distributed?
2. Should App Store / Google Play launch be part of public launch, or a separate post-web launch milestone?
3. Which user roles require runtime lock-screen recovery proof before broad field-heavy rollout?
4. Which field workflows require automatic sync versus manual retry in the next reliability expansion?
5. Which provider surfaces are allowed to remain disabled or read-only during pilot?

## Evidence Still Required

| Gate | Evidence | Status |
| --- | --- | --- |
| BN18D | Field reliability/offline matrix | Generated |
| BN18D | Offline security model | Drafted |
| BN18D | Offline implementation plan | Drafted |
| BN18D | Source proof for retry, duplicate prevention, drafts, and missing full-offline capabilities | Generated |
| BN18D | Founder online-first / limited-field-recovery posture | Accepted |
| BN18D | Airplane mode, network drop, lock screen, refresh, retry, conflict runtime screenshots | Optional follow-up / founder decision |
| BN18E | App Store / Google Play readiness checklist | Planned |
| BN18E | Store metadata, privacy, support, billing, review evidence | Missing |
| BN19 | Founder acceptance ledger including BN18D/BN18E | Missing |
| BN20 / BN12 | Staging/UAT closure package | Pending BN19 |
| BN21 | First-client pilot go/no-go | Pending BN19/BN20 |
| BN22 | Public launch gate | Pending pilot |

## Linked Planning Docs

- [Launch Trust Current Plan](LAUNCH_TRUST_CURRENT_PLAN.md)
- [Field Reliability Offline Matrix](FIELD_RELIABILITY_OFFLINE_MATRIX.md)
- [Offline Security Model](OFFLINE_SECURITY_MODEL.md)
- [Offline Implementation Plan](OFFLINE_IMPLEMENTATION_PLAN.md)
- [App Store Production Readiness](APP_STORE_PRODUCTION_READINESS.md)
- [BN18D/BN18E Current State Scan](../outputs/bn18d_bn18e_current_state_scan.md)
