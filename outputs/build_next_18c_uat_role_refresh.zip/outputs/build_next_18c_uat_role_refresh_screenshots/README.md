# BN18C Screenshot Evidence

Fresh BN18C screenshots were captured on 2026-07-05 against:

- Frontend: `https://app.equine-sync.com`
- API: `https://api.equine-sync.com`

The production gate passed before this evidence was registered:

- `/api/health` returned `status=ok`, `database=connected`, and
  `environment=production`.
- `/api/health/ready` returned `status=ok` and `indexes_ensured=True`.

## Required Evidence

- `uat-r1-platform-admin.png`
- `uat-r2a-facility-admin.png`
- `uat-r2b-barn-owner.png`
- `uat-r3-barn-manager.png`
- `uat-r4a-groom.png`
- `bn13m-t1-trainer.png`
- `bn13m-w1-working-student.png`
- `uat-r5-horse-owner.png`
- `uat-r6-guardian-parent.png`
- `uat-r7-rider.png`
- `uat-r8-individual-owner.png`
- `privacy-sweep.md`

## Supporting Evidence

- `uat-r2a-facility-admin-setup.png`
- `uat-r2b-barn-owner-setup.png`

## Privacy Boundary

The screenshot set was reviewed as visual evidence only. It should not expose
staff notes, raw daily-check payload internals, alert triggers,
`source_check_id`, audit diffs, auth tokens, passwords, Stripe IDs, DocuSign
secrets, or private owner/admin-only fields.

## Manual Review Note

The BN18C proof helper validates file existence and image signatures. It does
not make visual product judgments. Founder/Codex review should inspect each
screenshot directly, especially guardian and rider evidence, where current
navigation is role-specific but the main dashboard body resolves to the shared
Stable Command facility surface.
