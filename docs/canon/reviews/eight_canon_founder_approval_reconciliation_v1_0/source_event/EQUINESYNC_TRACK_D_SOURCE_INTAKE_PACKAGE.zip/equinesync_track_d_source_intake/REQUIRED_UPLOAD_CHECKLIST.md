# Required Upload Checklist for Final Track D Exact-Byte ZIP

Attach or mount the following:

- `EquineSync_Cross_Canon_Reconciliation_Package_V1_0.zip`
  - expected SHA-256: `937c3f702bf23eb89addfee50f17c707a38f0355abace710d23088304fa66f55`
  - supplies exact C0-039 and C0-040 source members
- the exact founder-accepted Privacy V2.0 source
- the exact founder-accepted Search V2.0 source
- `MASTER_REPORTING_ANALYTICS_AND_BUSINESS_INTELLIGENCE_MODEL_V2_0.md`
- `MASTER_VENDOR_SECURITY_AND_SUPPLY_CHAIN_MODEL_V2_0_FOUNDER_ACCEPTED.docx`
- `MASTER_CONFIGURATION_AND_FEATURE_FLAG_GOVERNANCE_MODEL_V2_0.docx`

Do not substitute a first draft for an accepted source unless the founder decision evidence identifies that exact first-draft byte state as accepted.
